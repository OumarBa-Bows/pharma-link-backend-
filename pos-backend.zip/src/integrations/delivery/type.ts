import { DeliveryStatus } from "../../enums/DeliveryStatus";

export interface DeliveryRequest {
  pickup_location: {
    latitude: number;
    longitude: number;
  };
  delivery_location: {
    latitude: number;
    longitude: number;
  };
  pickup_phone: string;
  delivery_phone: string;
  receiver_phone?: string;
  delivery_fee: number;
  delivery_address: string;
  delivery_address_ar: string;
  pickup_address: string;
  pickup_address_ar: string;
  origin: string | "LIIVIPOS";
  status?: DeliveryStatus;
  scheduled_at?:any|null
  business_code: string[];
  additional_pickups?: {
    pickup_address: string;
    pickup_address_ar: string;
    pickup_location: { latitude: number; longitude: number } | null;
  }[];
  location_accuracy_details?: {
    is_pickup_location_accurate: boolean;
    is_delivery_location_accurate: boolean;
  };
  notes?: string;
  voice_note_url?: string | null;
}

export interface CancelDeliveryRequest {
  delivery_id: number;
}
