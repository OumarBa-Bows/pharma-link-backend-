import axios from "axios"
import { CancelDeliveryRequest, DeliveryRequest } from "./type"
import { logger } from "../../app"
import * as Sentry from "@sentry/node"

const deliveryApi = axios.create({
  baseURL: process.env.WHEELS_DELIVERY_URL || "https://api.itkann.org/itkann-dev",
  timeout: 5000, // optionnel
  headers: {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${process.env.WHEELS_DELIVERY_TOKEN || ""}`, // Assurez-vous que la clé API est définie dans vos variables d'environnement
    "x-auth-itkann": process.env.ITKANN_API_KEY || ""
  },
})

export class DeliveryIntegration {
 
    static async requestDelivery(payload: DeliveryRequest): Promise<any> {
    try {
      logger.info(`Delivery Create Request ##`)
      const response = await deliveryApi.post("/api/course-delivery/create", payload)

      console.log("✅ Delivery API call successful:", response.status)
      if (!response.data ) {
        throw new Error("Invalid response from delivery API")
      }
      else if(response.data.error) {
        throw new Error(response.data.error)
      }
      else if(response.status!=200) {
        throw new Error("Delivery ID not found in response")
      }
      else if(!response.data.data.id) {
        throw new Error("Delivery ID not found in response")
      }
      return response.data.data;
    } catch (error: any) {
      Sentry.captureException(error);
      console.error("❌ Delivery API call failed:", error.response?.data || error.message)
      throw new Error("Échec de la demande de livraison")
    }
  }

    static async deleteDelivery(deliveryId: number): Promise<any> {
    try {
      logger.info(`CALL DELETE DELIVERY REQUEST : ${deliveryId}`)
      const response = await deliveryApi.post(`/api/course-delivery/delete-waiting/${deliveryId}`,)
      console.log("✅ Delivery API call successful:", response.status)
      if (!response.data ) {
        throw new Error("Invalid response from delivery API")
      }
      else if(response.data.error) {
        throw new Error(response.data.error)
      }
      else if(response.status!=200) {
        throw new Error("Delete Delivery Failed")
      }
      return response.data;
    } catch (error: any) {
      Sentry.captureException(error);
      console.error("❌ Delivery API call failed:", error.response?.data || error.message)
      throw new Error("Échec de la demande de livraison")
    }
  }

  static async cancelDelivery(payload:CancelDeliveryRequest): Promise<any> {
    try {
      logger.info(`CALL Cancel DELIVERY REQUEST : ${payload.delivery_id}`)
      const response = await deliveryApi.post(`/api/delivery/cancel`,payload)
      console.log("✅ Delivery API call successful:", response.status)
      if (!response.data ) {
        throw new Error("Invalid response from delivery API")
      }
      else if(response.data.error) {
        throw new Error(response.data.error)
      }
      else if(response.status!=200) {
        throw new Error("Cancel Delivery Failed")
      }
      return response.data;
    } catch (error: any) {
      Sentry.captureException(error);
      console.error("❌ Delivery API call failed:", error.response?.data || error.message)
      throw new Error("")
    }
  }

  static async updateToFindingDelivery(payload:{delivery_id:number}): Promise<any> {
    try {
      logger.info(`CALL Update DELIVERY REQUEST : ${payload.delivery_id}`)
      const response = await deliveryApi.post(`/api/course-delivery/update-to-finding-driver`,payload)
      console.log("✅ Delivery update API call successful:", response.status)
      if (!response.data ) {
        throw new Error("Invalid response from delivery API")
      }
      else if(response.data.error) {
        throw new Error(response.data.error)
      }
      else if(response.status!=200) {
        throw new Error("Update Delivery Failed")
      }
      return response.data;
    } catch (error: any) {
      Sentry.captureException(error);
      console.error("❌ Delivery API call failed:", error.response?.data || error.message)
      throw new Error("updateToFindingDelivery Failed")
    }
  }



}
