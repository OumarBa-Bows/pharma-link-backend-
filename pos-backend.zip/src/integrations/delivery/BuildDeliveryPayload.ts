import { Geometry } from "wkx";
import { Order } from "../../entities/Order.entity";
import { DeliveryRequest } from "./type";
import { getLatLngFromGeoPoint } from "../../utils/location/location";
import { DeliveryStatus } from "../../enums/DeliveryStatus";

export function buildDeliveryPayload(
  order: Order,
  deliveryData: any,
  businessCodes?: string[]
): DeliveryRequest {
  if (!order.business?.code) {
    throw new Error("Business code is missing from order");
  }

  if (order.origin !== "LIIVIPOS" || order.scheduled_at) {
    deliveryData.status = DeliveryStatus.WAITING; // Default status if not provided
  }

  const payload: DeliveryRequest = {
    pickup_location: deliveryData.pickup_location,
    delivery_location: deliveryData.delivery_location,
    pickup_phone: order.business.phone || "00000000", // fallback si vide
    delivery_phone: order.customer_phone!,
    delivery_fee: deliveryData.delivery_fee || 0,
    delivery_address: deliveryData.delivery_address!,
    delivery_address_ar: deliveryData.delivery_address_ar, // TODO: optionnellement générer en arabe
    pickup_address: deliveryData.pickup_address,
    pickup_address_ar: deliveryData.pickup_address_ar,
    origin: order.origin || "LIIVIPOS",
    business_code: businessCodes ?? [order.business.code],
    additional_pickups: deliveryData.additional_pickups,
    status: deliveryData.status,
    scheduled_at:order.scheduled_at,
    location_accuracy_details: deliveryData.location_accuracy_details,
    notes: deliveryData.notes ?? "",
    receiver_phone: deliveryData.receiver_phone || deliveryData.delivery_phone,
  };

  if (deliveryData.voice_note_url) {
    payload.voice_note_url = deliveryData.voice_note_url;
  }

  return payload;
}
