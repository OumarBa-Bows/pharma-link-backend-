import { Router } from "express";
import { authorize } from "../middlewares/auth";
import { Order } from "../entities/Order.entity";
import { OrderController } from "../controllers/OrderController";
import { validateCancelOrderPayment, validateConfirmOrder, validateCreateMultiBusinessOrder, validateCreateOrder, validateCreateOrderPayment, validateDispatchOrder, validateRejectOrder, validateUpdateOrder } from "../middlewares/order.middleware";
import { PaymentController } from "../controllers/PaymentController";
import { ItemVirtualAvailabilityController } from "../controllers/ItemAvailabilityController";


//  Courser  delivery (livii . express)  Router instance
const orderRoute = Router();


// create  order endpoint  
orderRoute.post(
    "/create",
    authorize(['admin','customer','deliver','wheels']),
    validateCreateOrder,
    OrderController.createOrder

)

orderRoute.post(
    "/create-multi-orders",
    authorize(['admin','customer','deliver','wheels']),
    validateCreateMultiBusinessOrder,
    OrderController.createMultiBusinessOrder

)

orderRoute.post(
    "/update",
    authorize(['admin','customer','deliver','wheels']),
    validateUpdateOrder,
    OrderController.updateOrder

)

orderRoute.post(
    "/confirm-order",
    authorize(['admin','customer','employee','deliver','wheels']),
    validateConfirmOrder,
    OrderController.confirmOrder

)

orderRoute.post(
    "/reject",
    authorize(['admin','employee']),
    validateRejectOrder,
    OrderController.rejectOrder

)

orderRoute.post(
    "/dispatch",
    authorize(['admin','employee']),
    validateDispatchOrder,
    OrderController.dispatchOrder

)

orderRoute.post(
    "/add-payment",
    authorize(['admin','employee','manager']),
    validateCreateOrderPayment,
    PaymentController.createOrderPayment
)

orderRoute.post(
    "/cancel-payment",
    authorize(['admin','employee','manager']),
    validateCancelOrderPayment,
    PaymentController.cancelOrderPayment
)

orderRoute.post(
    "/product/estimated-delivery",
   
    ItemVirtualAvailabilityController.getProductEstimatedDelivery
)


export default orderRoute;
