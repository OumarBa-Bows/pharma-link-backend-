import { Router } from "express";
import serverUpController from "../controllers/server-up";
import syncDeliveryOrderController from "../controllers/sync-delivery-order";
import {
  syncBusinessesToMeilisearch,
  searchBusinesses,
  syncBusinessFromTrigger,
} from "../controllers/business.controller";
import {
  syncProductFromTrigger,
  deleteProductFromTrigger,
  searchProducts,
  syncBusinessProductsToMeilisearch,
} from "../controllers/product.controller";
import { authorize } from "../middlewares/auth";

const router = Router();

router.get("/server-up", serverUpController.serverUp);
router.post(
  "/sync-delivery-order",
  authorize(["admin"]),
  syncDeliveryOrderController.syncDeliveryOrder
);
router.get(
  "/business/sync-businesses",
  authorize(["admin"]),
  syncBusinessesToMeilisearch
);
router.post("/business/search", searchBusinesses);
router.post(
  "/webhook/business-sync",
  authorize(["admin"]),
  syncBusinessFromTrigger
);

router.post(
  "/products/sync-trigger",
  authorize(["admin"]),
  syncProductFromTrigger
);

router.post(
  "/products/search",
  authorize(["admin", "customer", "deliver", "wheels"]),
  searchProducts
);
router.delete(
  "/products/sync-trigger/delete",
  authorize(["admin"]),
  deleteProductFromTrigger
);

router.post(
  "/products/sync-business",
  authorize(["admin"]),
  syncBusinessProductsToMeilisearch
);

export default router;
