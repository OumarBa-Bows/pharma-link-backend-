import { Router } from "express";
import { authorize } from "../middlewares/auth";
import { validateFetchInPreparationItemVirtual, validateItemVirtualCompletion, validateItemVirtualCreation, validateItemVirtualEdit } from "../middlewares/Item_virtual_availability.middleware";
import { ItemVirtualAvailabilityController } from "../controllers/ItemAvailabilityController";

const virtualItemRoute = Router();

virtualItemRoute.post(
    "/create",
    authorize(['manager','employee', 'admin']),
    validateItemVirtualCreation,
    ItemVirtualAvailabilityController.createVirtualAvailability
)

virtualItemRoute.post(
    "/complete",
    authorize(['manager','employee', 'admin']),
    validateItemVirtualCompletion,
    ItemVirtualAvailabilityController.completeVirtualAvailability
)

virtualItemRoute.post(
    "/fetch-in-preparation",
    authorize(['manager','employee', 'admin']),
    validateFetchInPreparationItemVirtual,
    ItemVirtualAvailabilityController.getVirtualItemsInPreparation
)


virtualItemRoute.post(
    "/edit",
    authorize(['manager','employee', 'admin']),
    validateItemVirtualEdit,
    ItemVirtualAvailabilityController.editVirtualAvailability
)

export default virtualItemRoute;