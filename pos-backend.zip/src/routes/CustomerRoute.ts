import { Router } from "express";
import { authorize } from "../middlewares/auth";
import { CustomerCOntroller } from "../controllers/CustomerController";

const customerRoute = Router();

// order reminder endpoint
customerRoute.post(
    "/update-lang",
    authorize(['customer', 'deliver', 'wheels']),
    CustomerCOntroller.updateCustomer

)

export default customerRoute;