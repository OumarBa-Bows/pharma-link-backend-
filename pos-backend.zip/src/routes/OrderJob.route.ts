import { Router } from "express";
import { OrderJobController } from "../controllers/OrderJobController";


const orderJobRoute = Router();

// order reminder endpoint
orderJobRoute.post(
    "/order-reminder",
    OrderJobController.createReminder

)

export default orderJobRoute;