import { Router } from "express";
import { authorize } from "../middlewares/auth";
import { validateCashInOperation, validateCashOutOperation } from "../middlewares/operation.middleware";
import { OperationController } from "../controllers/OperationController";


const operationRoute = Router();


// cashin operation  endpoint  
operationRoute.post(
    "/cashin",
    authorize(['admin','employee','manager']),
    validateCashInOperation,
    OperationController.cashInOperation
)

// cashout operation  endpoint  
operationRoute.post(
    "/cashout",
    authorize(['admin','employee','manager']),
    validateCashOutOperation,
    OperationController.cashOutOperation
)

export default operationRoute;