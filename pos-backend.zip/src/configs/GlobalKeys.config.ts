export const GlobalKeys = {
    MAX_RETRY_KEY: 'maxRetriesLoop', 
    ORDER_JOB_NAME_KEY: 'order-job-',

    PENDING_ORDER_KEY:'pendingOrder_',
    SCHEDULED_ORDER_KEY:'scheduledOrder_',
    VIRTUAL_ITEM_PREP_KEY:"virtualItemPrep_",
    
 }