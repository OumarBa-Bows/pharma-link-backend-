export const GlobalSettingValue = {
    PENDING_ORDER_TTL:300,
    SCHEDULE_ORDER_TIME:20

    
 }