export const SYSTEM_MESSAGES = {
  WHEN_USER_TRIES_TO_LOGIN_TO_THE_APP: {
    fr: `Bienvenue chez Deliciously Chicken 🍗
Votre code de connexion est {code}
Ou cliquez ici pour vous connecter directement : {lien}
Si le lien ne fonctionne pas, répondez à ce message ou enregistrez ce numéro.
Ce numéro est réservé aux messages automatiques. Pour nous contacter, appelez le 49125151.
Répondez par 1 pour recevoir les messages en arabe, ou 2 pour français.`,

    ar: `مرحبًا بكم في Deliciously Chicken 🍗
رمز الدخول الخاص بكم هو {code}
أو اضغط هنا للدخول مباشرة: {lien}
إذا لم يعمل الرابط، يرجى الرد على هذه الرسالة أو حفظ الرقم.
هذا الرقم مخصص للرسائل التلقائية فقط. للتواصل معنا، اتصلوا على 49125151.
للغة العربية أرسل 1، وللـ فرنسية أرسل 2.`
  },

  AT_ORDER_CREATION_PICKUP_ORDERS: {
    fr: `Commande à emporter a bien été reçue ✅
Notre équipe pourrait vous appeler pour la confirmer, restez attentif à votre téléphone.
Vous recevrez une notification dès que la commande sera confirmée.`,

   ar: `تم استلام طلبكم بنجاح ✅
قد يتصل بكم أحد أفراد فريقنا لتأكيد الطلب، الرجاء الانتباه لهاتفكم.
ستصلكم رسالة أخرى عند تأكيد الطلب.`
  },

  AT_ORDER_CONFIRMATION_PICKUP_ORDERS: {
    fr: `Votre commande a été confirmée ✅
Elle sera prête dans environ 30 minutes.
Merci de communiquer votre numéro de ticket au personnel du restaurant lors de votre arrivée.
Numéro de ticket : {ticket}`,

  ar: `تم تأكيد طلبكم ✅
سيكون جاهزًا خلال 30 دقيقة تقريبًا.
يرجى إبلاغ موظفي المطعم برقم الطلب عند الوصول.
رقم الطلب: {ticket}`
  },

  AT_ORDER_DISPATCHED_PICKUP_ORDERS: {
    fr: `Merci pour votre confiance 🙏
Bon appétit ! 😋
Vos retours sont les bienvenus sur WhatsApp au 49125151.
À très bientôt !`,

    ar: `شكرًا لثقتكم بنا 🙏
نتمنى لكم وجبة شهية! 😋
يسعدنا استقبال ملاحظاتكم عبر واتساب على الرقم 49125151
ونتطلع لخدمتكم مرة أخرى قريبًا!`
  },

  AT_ORDER_CANCELLATION: {
    fr: `Votre commande a été annulée ❌
Pour plus d'informations, veuillez contacter le personnel du restaurant au 49125151.`,

    ar: `تم إلغاء طلبكم ❌
لمزيد من المعلومات، يرجى التواصل مع موظفي المطعم على الرقم 49125151.`
  },

  AT_ORDER_CREATION_DELIVERY_ORDERS: {
    fr: `Votre commande a été reçue avec succès ✅
Un membre de notre équipe pourrait vous appeler pour la confirmer.
Vous recevrez une notification une fois la commande confirmée.
La livraison sera assurée par notre partenaire Livii.`,

    ar: `تم استلام طلبكم بنجاح ✅
قد يتصل بكم أحد موظفينا لتأكيد الطلب.
ستصلكم رسالة عند تأكيد الطلب.
سيتم توصيل الطلب عبر شريكنا Livii.`
  },

  AT_ORDER_CONFIRMATION_DELIVERY_ORDERS: {
    fr: `Votre commande a été confirmée ✅
Vous recevrez bientôt une notification de notre partenaire Livii pour suivre la livraison.
Nous vous enverrons un message dès que la commande sera remise au livreur.`,

    ar: `تم تأكيد طلبكم ✅
ستصلكم قريبًا رسالة من شريكنا Livii لتتبع التوصيل.
وسنرسل لكم إشعارًا عند تسليم الطلب إلى السائق.`
  },

  AT_ORDER_DISPATCHED_DELIVERY_ORDERS: {
    fr: `Votre commande a été remise au livreur 🛵
Vous avez dû recevoir un message de suivi de notre partenaire Livii.
Merci pour votre confiance 🙏
Bon appétit ! 😋
Vos retours sont les bienvenus sur WhatsApp au 49125151.
À très bientôt !`,

    ar: `تم تسليم طلبكم للسائق 🛵
من المفترض أنكم استلمتم رسالة من شريكنا Livii لتتبع التوصيل.
شكرًا لثقتكم بنا 🙏
نتمنى لكم وجبة شهية! 😋
نرحب بأي ملاحظات على واتساب عبر الرقم 49125151
ونسعد بخدمتكم مرة أخرى قريبًا!`
  }
} 