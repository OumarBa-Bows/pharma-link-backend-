import { meilisearchClient, supabase } from "../app";

const synonyms = {
  carrefour: [
    "تقاطع الطرق",
    "intersection",
    "croisement",
    "carrefour",
    "carafour",
    "carrafour",
    "carefour",
    "كرفور",
  ],
  "تقاطع الطرق": [
    "carrefour",
    "intersection",
    "croisement",
    "carrefour",
    "carafour",
    "carrafour",
    "carefour",
    "كرفور",
  ],
  كرفور: [
    "carrefour",
    "intersection",
    "croisement",
    "carrefour",
    "carafour",
    "carrafour",
    "carefour",
    "تقاطع الطرق",
  ],
  intersection: [
    "carrefour",
    "تقاطع الطرق",
    "croisement",
    "carrefour",
    "carafour",
    "carrafour",
    "carefour",
    "كرفور",
  ],
  croisement: [
    "carrefour",
    "تقاطع الطرق",
    "intersection",
    "carrefour",
    "carafour",
    "carrafour",
    "carefour",
    "كرفور",
  ],
  carafour: [
    "carrefour",
    "تقاطع الطرق",
    "intersection",
    "croisement",
    "carrefour",
    "carrafour",
    "carefour",
    "كرفور",
  ],
  carrafour: [
    "carrefour",
    "تقاطع الطرق",
    "intersection",
    "croisement",
    "carrefour",
    "carafour",
    "carefour",
    "كرفور",
  ],
  carefour: [
    "carrefour",
    "تقاطع الطرق",
    "intersection",
    "croisement",
    "carrefour",
    "carafour",
    "carrafour",
    "كرفور",
  ],
  stade: ["ستاد", "ملعب", "terrain", "football", "استاد"],
  ستاد: ["stadium", "ملعب رياضي", "stade", "stade de football"],
  استاد: ["stade", "ستاد", "ملعب", "terrain", "football"],
  ملعب: ["stade", "ستاد", "استاد", "terrain", "football"],
  terrain: ["stade", "ستاد", "استاد", "ملعب", "football"],
  football: ["stade", "ستاد", "استاد", "ملعب", "terrain"],
  restaurant: ["مطعم", "مأكولات", "مقهى", "fast food"],
  مطعم: ["restaurant", "مأكولات", "مقهى", "fast food"],
  مأكولات: ["restaurant", "مطعم", "مقهى", "fast food"],
  "fast food": ["restaurant", "مطعم", "مأكولات", "مقهى"],
  embassy: ["سفارة", "ambassade", "ambasade", "ambasade"],
  سفارة: ["embassy", "ambassade", "ambasade", "ambasade"],
  ambassade: ["embassy", "سفارة", "ambasade", "ambasade"],
  ambasade: ["embassy", "سفارة", "ambassade"],
  university: [
    "جامعة",
    "مؤسسة تعليمية",
    "جامعة أكاديمية",
    "université",
    "معهد",
    "facultè",
    "كلية",
  ],
  جامعة: [
    "university",
    "مؤسسة تعليمية",
    "جامعة أكاديمية",
    "université",
    "معهد",
    "facultè",
    "كلية",
  ],
  "مؤسسة تعليمية": [
    "school",
    "مدرسة",
    "مدرسة ابتدائية",
    "école",
    "école secondaire",
    "facultè",
    "كلية",
  ],
  "جامعة أكاديمية": [
    "university",
    "جامعة",
    "مؤسسة تعليمية",
    "université",
    "معهد",
    "facultè",
    "كلية",
  ],
  université: [
    "university",
    "جامعة",
    "مؤسسة تعليمية",
    "جامعة أكاديمية",
    "معهد",
    "facultè",
    "كلية",
  ],
  facultè: [
    "university",
    "جامعة",
    "مؤسسة تعليمية",
    "جامعة أكاديمية",
    "معهد",
    " université",
    "كلية",
  ],
  معهد: [
    "university",
    "جامعة",
    "مؤسسة تعليمية",
    "جامعة أكاديمية",
    "université",
    "facultè",
    "كلية",
  ],
  كلية: [
    "university",
    "جامعة",
    "مؤسسة تعليمية",
    "جامعة أكاديمية",
    "université",
    "facultè",
    "معهد",
  ],
  school: [
    "مدرسة",
    "مؤسسة تعليمية",
    "مدرسة ابتدائية",
    "école",
    "école secondaire",
  ],
  مدرسة: [
    "school",
    "مؤسسة تعليمية",
    "مدرسة ابتدائية",
    "مدارس",
    "école",
    "école secondaire",
  ],
  "مدرسة ابتدائية": [
    "school",
    "مدرسة",
    "مؤسسة تعليمية",
    "école",
    "école secondaire",
  ],
  école: [
    "school",
    "مدرسة",
    "مدارس",
    "مؤسسة تعليمية",
    "مدرسة ابتدائية",
    "école secondaire",
  ],
  "école secondaire": [
    "school",
    "مدرسة",
    "مؤسسة تعليمية",
    "مدرسة ابتدائية",
    "école",
  ],
  hospital: ["مستشفى", "مستشفى عام", "طب", "مستوصف", "hôpital", "clinique"],
  مستشفى: ["hospital", "مستشفى عام", "hôpital", "طب", "مستوصف", "clinique"],
  "مستشفى عام": ["hospital", "مستشفى", "طب", "hôpital", "مستوصف", "clinique"],
  طب: ["hospital", "مستشفى", "hôpital", "مستوصف", "clinique"],
  hôpital: ["hospital", "مستشفى", "مستشفى عام", "مستوصف", "clinique"],
  clinique: [
    "hospital",
    "مستشفى",
    "مصحة",
    "عيادة",
    "مستشفى عام",
    "مستوصف",
    "hôpital",
  ],
  مصحة: [
    "hospital",
    "مستشفى",
    "clinique",
    "عيادة",
    "مستشفى عام",
    "مستوصف",
    "hôpital",
  ],
  عيادة: [
    "hospital",
    "مستشفى",
    "clinique",
    "مصحة",
    "مستشفى عام",
    "مستوصف",
    "hôpital",
  ],
  bookstore: ["مكتبة", "محل كتب", "دار نشر", "librairie"],
  مكتبة: ["library", "مكتبة عامة", "مكتبة مراجع", "bibliothèque"],
  "محل كتب": ["bookstore", "مكتبة", "دار نشر", "librairie"],
  "دار نشر": ["bookstore", "مكتبة", "محل كتب", "librairie"],
  librairie: ["bookstore", "مكتبة", "محل كتب", "دار نشر"],
  cafe: ["مقهى", "كافيتيريا", "مقهى الإنترنت", "café", "salon de thé"],
  مقهى: ["cafe", "كافيتيريا", "مقهى الإنترنت", "café", "salon de thé"],
  كافيتيريا: ["cafe", "مقهى", "مقهى الإنترنت", "café", "salon de thé"],
  "مقهى الإنترنت": ["cafe", "مقهى", "كافيتيريا", "café", "salon de thé"],
  café: ["cafe", "مقهى", "كافيتيريا", "مقهى الإنترنت", "salon de thé"],
  "salon de thé": ["cafe", "مقهى", "كافيتيريا", "مقهى الإنترنت", "café"],
  supermarket: ["سوبر ماركت", "محل", "متجر", "supermarché"],
  "سوبر ماركت": ["supermarket", "محل", "متجر", "مجمع", "supermarché"],
  مجمع: ["supermarket", "محل", "متجر", "سوبر ماركت", "supermarché"],
  محل: ["supermarket", "سوبر ماركت", "متجر", "supermarché"],
  متجر: ["supermarket", "سوبر ماركت", "محل", "supermarché"],
  supermarché: ["supermarket", "سوبر ماركت", "محل", "متجر"],
  hotel: ["فندق", "مرفق إقامة", "نزل", "hôtel", "شقق", "auberge"],
  فندق: ["hotel", "مرفق إقامة", "نزل", "hôtel", "شقق", "auberge"],
  "مرفق إقامة": ["hotel", "فندق", "نزل", "شقق", "hôtel", "auberge"],
  نزل: ["hotel", "فندق", "مرفق إقامة", "hôtel", "شقق", "auberge"],
  شقق: ["hotel", "فندق", "مرفق إقامة", "hôtel", "نزل", "auberge"],
  hôtel: ["hotel", "فندق", "مرفق إقامة", "نزل", "شقق", "auberge"],
  auberge: ["hotel", "فندق", "مرفق إقامة", "نزل", "شقق", "hôtel"],
  library: ["مكتبة", "مكتبة عامة", "مكتبة مراجع", "bibliothèque"],
  "مكتبة عامة": ["library", "مكتبة", "مكتبة مراجع", "bibliothèque"],
  "مكتبة مراجع": ["library", "مكتبة", "مكتبة عامة", "bibliothèque"],
  bibliothèque: ["library", "مكتبة", "مكتبة عامة", "مكتبة مراجع"],
  stadium: ["ستاد", "ملعب رياضي", "stade", "stade de football"],
  "ملعب رياضي": ["stadium", "ستاد", "stade", "stade de football"],
  "stade de football": ["stadium", "ستاد", "ملعب رياضي", "stade"],
  park: [
    "حديقة",
    "منتزه",
    "مساحة خضراء",
    "parc",
    "أبارك",
    "ساحة",
    "jardin public",
  ],
  حديقة: [
    "park",
    "منتزه",
    "مساحة خضراء",
    "parc",
    "أبارك",
    "ساحة",
    "jardin public",
  ],
  أبارك: [
    "park",
    "منتزه",
    "مساحة خضراء",
    "parc",
    "حديقة",
    "ساحة",
    "jardin public",
  ],
  منتزه: ["park", "حديقة", "مساحة خضراء", "parc", "ساحة", "jardin public"],
  ساحة: ["park", "حديقة", "مساحة خضراء", "parc", "منتزه", "jardin public"],
  "مساحة خضراء": ["park", "حديقة", "منتزه", "parc", "jardin public"],
  parc: ["park", "حديقة", "منتزه", "مساحة خضراء", "jardin public"],
  "jardin public": ["park", "حديقة", "منتزه", "مساحة خضراء", "parc"],
  cinema: ["سينما", "دار سينما", "مسرح سينمائي", "cinéma"],
  سينما: ["cinema", "دار سينما", "مسرح سينمائي", "cinéma"],
  "دار سينما": ["cinema", "سينما", "مسرح سينمائي", "cinéma"],
  "مسرح سينمائي": ["cinema", "سينما", "دار سينما", "cinéma"],
  cinéma: ["cinema", "سينما", "دار سينما", "مسرح سينمائي"],
  mosque: ["مسجد", "mosquée", "جامع", "مسيد"],
  مسجد: ["mosque", "mosquée", "جامع", "مسيد"],
  جامع: ["mosque", "mosquée", "مسجد", "مسيد"],
  mosquée: ["mosque", "مسجد", "جامع", "مسيد"],
  مسيد: ["mosque", "مسجد", "جامع", "mosquée"],
  church: ["كنيسة", "église"],
  كنيسة: ["church", "église"],
  église: ["church", "كنيسة"],
  airport: ["مطار", "مطار دولي", "aéroport"],
  مطار: ["airport", "مطار دولي", "aéroport"],
  "مطار دولي": ["airport", "مطار", "aéroport"],
  aéroport: ["airport", "مطار", "مطار دولي"],
  mall: ["مول", "مركز تسوق", "مجمع تجاري", "centre commercial"],
  مول: ["mall", "مركز تسوق", "مجمع تجاري", "centre commercial"],
  "مركز تسوق": ["mall", "مول", "مجمع تجاري", "centre commercial"],
  "مجمع تجاري": ["mall", "مول", "مركز تسوق", "centre commercial"],
  "centre commercial": ["mall", "مول", "مركز تسوق", "مجمع تجاري"],
  market: ["سوق", "سوق تجاري", "بازار", "marché", "مرصة", "marché local"],
  سوق: ["market", "سوق تجاري", "بازار", "marché", "مرصة", "marché local"],
  "سوق تجاري": ["market", "سوق", "بازار", "marché", "مرصة", "marché local"],
  مرصة: [
    "market",
    "سوق",
    "بازار",
    "marché",
    "سوق تجاري",
    "مرصت",
    "marché local",
  ],
  مرصت: [
    "market",
    "سوق",
    "بازار",
    "marché",
    "سوق تجاري",
    "مرصة",
    "marché local",
  ],
  بازار: ["market", "سوق", "سوق تجاري", "marché", "marché local"],
  marché: ["market", "سوق", "سوق تجاري", "بازار", "marché local"],
  "marché local": ["market", "سوق", "سوق تجاري", "بازار", "marché"],
  bank: ["بنك", "مؤسسة مالية", "مصرف", "banque", "établissement financier"],
  بنك: ["bank", "مؤسسة مالية", "مصرف", "banque", "établissement financier"],
  "مؤسسة مالية": ["bank", "بنك", "مصرف", "banque", "établissement financier"],
  مصرف: ["bank", "بنك", "مؤسسة مالية", "banque", "établissement financier"],
  banque: ["bank", "بنك", "مؤسسة مالية", "مصرف", "établissement financier"],
  "établissement financier": ["bank", "بنك", "مؤسسة مالية", "مصرف", "banque"],
  pharmacy: ["صيدلية", "مستودع صيدلي", "pharmacie"],
  صيدلية: ["pharmacy", "مستودع صيدلي", "pharmacie"],
  "مستودع صيدلي": ["pharmacy", "صيدلية", "pharmacie"],
  pharmacie: ["pharmacy", "صيدلية", "مستودع صيدلي"],
  bakery: [
    "مخبز",
    "مخبزة",
    "boulangerie",
    "Pâtisserie",
    "Four",
    "حلويات",
    "فور",
  ],
  مخبز: [
    "bakery",
    "مخبزة",
    "boulangerie",
    "Pâtisserie",
    "Four",
    "حلويات",
    "فور",
  ],
  مخبزة: [
    "bakery",
    "مخبز",
    "boulangerie",
    "Pâtisserie",
    "Four",
    "حلويات",
    "فور",
  ],
  minister: ["وزير", "وزارة", "ministre", "ministère", "ministry", "wizara"],
  وزير: ["minister", "وزارة", "ministre", "ministère", "ministry", "wizara"],
  وزارة: ["ministry", "وزير", "minister", "ministre", "ministère", "wizara"],
  ministre: ["minister", "وزير", "وزارة", "ministère", "ministry", "wizara"],
  ministère: ["ministry", "ministre", "وزارة", "وزير", "minister", "wizara"],
  ministry: ["وزارة", "وزير", "minister", "ministre", "ministère", "wizara"],
  wizara: ["وزارة", "ministry", "وزير", "minister", "ministre", "ministère"],
  boulangerie: [
    "bakery",
    "مخبز",
    "مخبزة",
    "Pâtisserie",
    "Four",
    "حلويات",
    "فور",
  ],
  Pâtisserie: [
    "bakery",
    "مخبز",
    "مخبزة",
    "boulangerie",
    "Four",
    "حلويات",
    "فور",
  ],
  Four: [
    "bakery",
    "مخبز",
    "مخبزة",
    "boulangerie",
    "Pâtisserie",
    "حلويات",
    "فور",
  ],
  حلويات: [
    "bakery",
    "مخبز",
    "مخبزة",
    "boulangerie",
    "Pâtisserie",
    "Four",
    "فور",
  ],
  فور: [
    "bakery",
    "مخبز",
    "مخبزة",
    "boulangerie",
    "Pâtisserie",
    "Four",
    "حلويات",
  ],
  boucherie: ["mejzara", "محل لحوم", "جزار", "boucher", "ملحمة"],
  mejzara: ["boucherie", "محل لحوم", "جزار", "boucher", "ملحمة"],
  "محل لحوم": ["boucherie", "mejzara", "جزار", "boucher", "ملحمة"],
  جزار: ["boucherie", "mejzara", "محل لحوم", "boucher", "ملحمة"],
  boucher: ["boucherie", "mejzara", "محل لحوم", "جزار", "ملحمة"],
  ملحمة: ["boucherie", "mejzara", "محل لحوم", "جزار", "boucher"],
};

interface PlaceData {
  id: number;
  name: string;
  name_ar: string;
  popularity: number;
  longitude: number;
  latitude: number;
  zone_name_fr: string;
  zone_name_ar: string;
  location: any;
}

export async function fetchPlacesFromSupabase(): Promise<PlaceData[]> {
  const { data, error } = await supabase
    .from("place_with_zone_view_v2")
    .select("*");

  if (error) {
    throw new Error(`Failed to fetch places: ${error.message}`);
  }

  return data || [];
}

export async function indexPlacesInMeiliSearch(places: PlaceData[]) {
  const indexName = process.env.MEILISEARCH_INDEX_PLACES || "";

  const documentsForMeili = places.map((place) => ({
    id: place.id,
    name: place.name,
    name_ar: place.name_ar,
    popularity: place.popularity,
    _geo: {
      lat: place.latitude,
      lng: place.longitude,
    },
    zone_name_fr: place.zone_name_fr,
    zone_name_ar: place.zone_name_ar,
    zone: place.zone_name_fr || place.zone_name_ar,
  }));
  console.log("Deleting all existing documents in MeiliSearch...");
  await meilisearchClient.index(indexName).deleteAllDocuments();
  const response = await meilisearchClient
    .index(indexName)
    .addDocuments(documentsForMeili);

  return response;
}

export async function syncPlacesToMeiliSearch() {
  try {
    console.log("Fetching places from Supabase...");
    const places = await fetchPlacesFromSupabase();
    console.log(`Fetched ${places.length} places`);

    console.log("Indexing places in MeiliSearch...");
    const response = await indexPlacesInMeiliSearch(places);
    console.log("Places indexed successfully:", response);

    return { success: true, count: places.length, taskUid: response.taskUid };
  } catch (error) {
    console.error("Error syncing places:", error);
    throw error;
  }
}

export async function configureMeilisearchPlacesIndex() {
  const indexName = process.env.MEILISEARCH_INDEX_PLACES || "places";
  await meilisearchClient
    .index(indexName)
    .updateSearchableAttributes(["name", "name_ar"]);
  await meilisearchClient.index(indexName).updateSettings({
    pagination: { maxTotalHits: 200 },
    rankingRules: [
      "sort", // 1) apply whatever you passed in `sort: [...]` first
      "words", // 2) break ties with text‐match relevance
      "typo",
      "proximity",
      "attribute",
      "exactness",
    ],
  });
  await meilisearchClient
    .index(indexName)
    .updateSortableAttributes(["_geo", "popularity"]);
  await meilisearchClient
    .index(indexName)
    .updateFilterableAttributes(["_geo", "popularity", "zone"]);
  meilisearchClient.index(indexName).updateSynonyms(synonyms);
  await meilisearchClient.index(indexName).updateTypoTolerance({
    minWordSizeForTypos: {
      oneTypo: 3,
      twoTypos: 6,
    },
  });
}
