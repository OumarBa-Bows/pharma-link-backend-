import { logger, meilisearchClient } from "../app";
import * as Sentry from "@sentry/node";

const businessIndexConfig = {
  searchableAttributes: ["business_name_fr", "business_name_ar", "phone"],

  filterableAttributes: [
    "status",
    "type",
    "is_started",
    "popularity",
    "is_open",
    "_geo",
  ],

  sortableAttributes: [
    "popularity",
    "created_at",
    "business_name_fr",
    "is_open",
    "_geo",
    "status",
  ],

  rankingRules: [
    "words",
    "typo",
    "proximity",
    "attribute",
    "sort",
    "exactness",
    "is_open:desc",
    "popularity:desc",
  ],

  typoTolerance: {
    enabled: true,
    minWordSizeForTypos: {
      oneTypo: 3,
      twoTypos: 6,
    },
    disableOnWords: [],
    disableOnAttributes: [],
  },

  pagination: {
    maxTotalHits: 300,
  },
};

export async function initMeilisearchbusinessIndex() {
  try {
    const businessIndexName = process.env.MEILISEARCH_INDEX_BUSINESSES || "";

    const businesssIndex = meilisearchClient.index(businessIndexName);

    await businesssIndex.updateSettings(businessIndexConfig);

    logger.info("business index settings updated successfully");
    return true;
  } catch (error) {
    logger.error(`Error initializing Meilisearch index: ${error}`);
    Sentry.captureException(error);
    throw error;
  }
}
