import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
  ManyToOne,
  JoinColumn,
} from "typeorm";

import { OperationNature } from "../enums/OperationNature";
import { Account } from "./Account.entity";

@Entity("operations")
export class Operation {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({type:"int",nullable:true})
  account_id?: number|null;

  @Column("numeric")
  amount: number;

  @Column("enum", { enum: OperationNature })
  nature: OperationNature;

  @Column({ type:"text",nullable:true })
  status: string;

  @Column({ type:"text",nullable:true })
  reason?: string|null;

  @CreateDateColumn()
  created_at: Date;

  @Column({ type: "double precision" })
  balance_before_transaction: number;

  @Column({ type: "double precision" })
  balance_after_transaction: number;

  @Column({type:"int",nullable:true})
  business_id?: number|null;

  @Column({ type: "int", nullable: true })
  order_id?: number|null;

    @ManyToOne(() => Account, (account) => account.operations)
    @JoinColumn({ name: "account_id" })
    account: Account;

 
}
