// src/entities/OrderPayment.ts

import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
} from "typeorm"
import { Order } from "./Order.entity"
import { PaymentType } from "./PaymentType.entity"
import { Business } from "./Business.entity"
import { PaymentStatus } from "../enums/PaymentStatus"


@Entity("order_payments")
export class OrderPayment {
  @PrimaryGeneratedColumn()
  id: number

  @Column()
  order_id: number

  @ManyToOne(() => Order, (order) => order.payments)
  @JoinColumn({ name: "order_id" })
  order: Order

  @Column()
  payment_type_id: number

  @ManyToOne(() => PaymentType)
  @JoinColumn({ name: "payment_type_id" })
  paymentType: PaymentType

  @Column({ type: "numeric", precision: 10, scale: 2 })
  amount: number

  @Column({ type: "text", nullable: true })
  transaction_reference: string | null

  @CreateDateColumn({ type: "timestamptz", default: () => "now()", name: "created_at" })
  created_at: Date

  @Column({ nullable: true })
  business_id: number | null

  @ManyToOne(() => Business)
  @JoinColumn({ name: "business_id" })
  business: Business

  @Column({
    type: "enum",
    enum: PaymentStatus,
    default: PaymentStatus.VALIDED,
    nullable: true,
  })
  status: PaymentStatus | null
}
