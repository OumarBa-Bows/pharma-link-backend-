import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { MenuItem } from './MenuItem.entity';  // Assure-toi que le chemin est correct
import { ItemPreparationStatus } from '../enums/ItemPreparationStatus';

@Entity({ name: 'item_virtual_availability' })
export class ItemVirtualAvailability {
  @PrimaryGeneratedColumn()
  id: number

  @CreateDateColumn({ type: 'timestamptz', name: 'created_at' })
  createdAt: Date;

  @CreateDateColumn({ type: 'timestamptz', name: 'available_at',nullable: true })
  available_at: Date;

  @Column({ type: 'int', name: 'prepartion_time' })
  prepartion_time: number;

  @Column({ type: 'double precision', default: 1 })
  quantity: number;

  @Column({ type: "int4", nullable: false })
  business_id: number;

  @Column({ type: 'enum', nullable: true, default: ItemPreparationStatus.IN_PREPARATION, enum: ItemPreparationStatus })
  status: ItemPreparationStatus | null;

  @Column({ type: 'int', name: 'menu_item_id' })
  menu_item_id: number;

  @ManyToOne(() => MenuItem, (menuItem) => menuItem.virtualAvailabilities)
  @JoinColumn({ name: 'menu_item_id' })
  menuItem: MenuItem;
}
