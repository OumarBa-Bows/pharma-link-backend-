import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  JoinColumn,
  ManyToOne,
  OneToMany,
} from "typeorm";
import { BusinessType } from "../enums/BusinessType";
import { PaymentType } from "./PaymentType.entity";

@Entity("business")
export class Business {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: "text" })
  business_name_fr: string;

  @Column({ type: "text" })
  business_name_ar: string;

  @Column({ type: "text", nullable: true })
  logo?: string;

  @Column({ type: "boolean", default: true, nullable: true })
  status: boolean;

  @Column({ type: "enum", enum: BusinessType, nullable: true })
  type?: BusinessType;

  @Column({ type: "uuid", nullable: true })
  owner_id: string;

  @CreateDateColumn({ type: "timestamptz", default: () => "now()" })
  created_at: Date;

  @UpdateDateColumn({ type: "timestamptz", default: () => "now()" })
  updated_at: Date;

  @Column({ type: "timestamptz", nullable: true })
  started_at?: Date;

  @Column({ type: "boolean", default: false, nullable: true })
  is_started: boolean;

  @Column({ type: "uuid", unique: true, default: () => "gen_random_uuid()" })
  code: string;

  @Column({ type: "geography", nullable: true })
  location?: any;

  @Column({ type: "text", nullable: true })
  phone?: string;

  @Column({ type: "text", nullable: true })
  whatsapp_number?: string;

  @Column({ type: "integer", default: 0, nullable: true })
  popularity: number;

  @Column({ type: "jsonb", nullable: true })
  zone?: any;

  @Column({ type: "boolean", default: false, nullable: true })
  is_open: boolean;

  @Column({ type: 'float8',nullable:true })
  acceptence_time?: number;

  @OneToMany(() => PaymentType, (paymentType) => paymentType.business)
  paymentTypes: PaymentType[];
}
