import {
  Entity,
  Column,
  ManyToOne,
  PrimaryColumn,
  JoinColumn,
  Index,
} from "typeorm"
import { Menu } from "./Menu.entity"
import { MenuItem } from "./MenuItem.entity"
import { Business } from "./Business.entity"

@Entity("menu_infos")
@Index("idx_menuitem_menu_id", ["menu"])
@Index("idx_menuitem_item_id", ["item"])
export class MenuInfo {
  @PrimaryColumn({ name: "menu_id", type: "integer" })
  menu_id!: number

  @PrimaryColumn({ name: "item_id", type: "integer" })
  item_id!: number

  @Column({name:"business_id", nullable:true, type:"integer"})
  business_id!: number

  @Column({ type: "double precision", default: 1 })
  quantity!: number

  @ManyToOne(() => Menu, { onDelete: "CASCADE" })
  @JoinColumn({ name: "menu_id" })
  menu!: Menu

  @ManyToOne(() => MenuItem, { onDelete: "CASCADE" })
  @JoinColumn({ name: "item_id" })
  item!: MenuItem

  @ManyToOne(() => Business, { nullable: true })
  @JoinColumn({ name: "business_id" })
  business?: Business
}
