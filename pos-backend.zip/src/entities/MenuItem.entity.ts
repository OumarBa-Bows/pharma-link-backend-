import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from "typeorm"
import { Category } from "./Category.entity"
import { Business } from "./Business.entity"
import { MenuItemType } from "../enums/MenuItemType"
import { MenuInfo } from "./MenuInfo.entity"
import { ItemVirtualAvailability } from "./ItemVirtualAvailabilty.entity"




@Entity("menu_item")
export class MenuItem {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: "text" })
  name_ar: string

  @Column({ type: "text" })
  name_fr: string

  @Column({ type: "text", nullable: true })
  description_fr?: string

  @Column({ type: "double precision", default: 0 })
  price: number

  @Column({ type: "boolean", default: false })
  is_sellable: boolean

  @Column({ type: "boolean", default: false })
  is_inventory_tracked: boolean

  @Column({ type: "enum", enum: MenuItemType })
  type: MenuItemType

  @ManyToOne(() => Category, { nullable: true, onDelete: "RESTRICT", onUpdate: "CASCADE" })
  @JoinColumn({ name: "category_id" })
  category?: Category

  @CreateDateColumn({ type: "timestamptz", name: "created_at", default: () => "now()" })
  created_at: Date

  @UpdateDateColumn({ type: "timestamptz", name: "updated_at", nullable: true })
  updated_at: Date

  @Column({ type: "text", nullable: true })
  image_url?: string

  @Column({ type: "text", nullable: true })
  description_ar?: string

  @Column({ type: "boolean", default: true })
  is_available: boolean

  @Column({ type: "double precision", default: 0 })
  quantity: number

  @Column({ type: "int4", nullable: false })
  business_id: number;
  
  @ManyToOne(() => Business, { onDelete: "CASCADE" })
  @JoinColumn({ name: "business_id" })
  business: Business

  @Column({ type: "uuid", default: () => "gen_random_uuid()" })
  code: string

  @Column({ type: "double precision", nullable: true })
  dailly_quantity?: number

  @OneToMany(() => MenuInfo, (menuInfo) => menuInfo.item)
  menuInfos!: MenuInfo[];

  @OneToMany(
    () => ItemVirtualAvailability,
    (itemVirtualAvailability) => itemVirtualAvailability.menuItem
  )
  virtualAvailabilities: ItemVirtualAvailability[];

   @Column({ type: 'float8',nullable:true })
  prep_time?: number;
}
