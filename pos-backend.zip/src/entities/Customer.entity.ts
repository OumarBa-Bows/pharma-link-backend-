import {
  Entity,
  PrimaryColumn,
  Column,
  CreateDateColumn,
  Index,
} from "typeorm"

@Entity("customer")
@Index("idx_customer_phone", ["phone"])
export class Customer {
  @PrimaryColumn({ type: "text" })
  phone!: string

  @Column({ type: "text", nullable: true })
  name?: string

  @Column({ type: "text", nullable: true })
  whatsapp_number?: string

  @Column({ type: "text", nullable: true })
  prefered_language?: string
  @Column({ type: "text", nullable: true })
  fcm_token?: string

  @CreateDateColumn({ type: "timestamp", default: () => "now()" })
  created_at!: Date
}

