import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm"
import { Order } from "./Order.entity"
import { Menu } from "./Menu.entity"
import { MenuItem } from "./MenuItem.entity"
import { ProductType } from "../enums/ProductType"



@Entity("order_items")
export class OrderItem {
  @PrimaryGeneratedColumn()
  id!: number

  @Column({ type: "integer" })
  order_id!: number

  @ManyToOne(() => Order, (order) => order.id, { onDelete: "CASCADE" })
  @JoinColumn({ name: "order_id" })
  order!: Order

  @Column({ type: "integer", nullable: true })
  id_menu?: number

  @ManyToOne(() => Menu, { nullable: true })
  @JoinColumn({ name: "id_menu" })
  menu?: Menu

  @Column({ type: "integer", nullable: true })
  id_item?: number

  @ManyToOne(() => MenuItem, { nullable: true })
  @JoinColumn({ name: "id_item" })
  item?: MenuItem

  @Column({ type: "integer" })
  quantity!: number

  @CreateDateColumn({ type: "timestamptz", default: () => "now()" })
  created_at!: Date

  @UpdateDateColumn({ type: "timestamptz", default: () => "now()" })
  updated_at!: Date

  @Column({ type: "enum", enum: ProductType, nullable: true })
  product_type?: ProductType
}
