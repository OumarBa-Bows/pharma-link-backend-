import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { Operation } from "./Operation.entity";

@Entity('accounts')
export class Account {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({type:'numeric'})
    balance: number;

    @Column({ type: 'text', nullable: false })
    type: string;

    @Column({type:'int4',nullable:true,})
    business_id: number;

    @CreateDateColumn({ type: 'timestamp without time zone' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp without time zone' })
    updated_at: Date;

    @OneToMany(() => Operation, (operation) => operation.account)
    operations: Operation[];
}