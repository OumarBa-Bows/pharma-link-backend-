import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { Order } from './Order.entity';
import { Business } from './Business.entity';
import { OrderJobStatus } from '../enums/OrderJobStatus';



@Entity({ name: 'order_jobs' })
export class OrderJob {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'text', nullable: true })
  name: string | null;

  @Column({ type: 'int', nullable: true })
  order_id: number | null;

  @Column({
    type: 'enum',
    enum: OrderJobStatus,
    nullable: true,
  })
  job_status: OrderJobStatus | null;

  @Column({ type: 'int', nullable: true })
  business_id: number | null;

  @CreateDateColumn({ type: 'timestamptz' })
  created_at: Date;

  // Relations (si les entités Order et Business existent)

  @ManyToOne(() => Order, { nullable: true })
  @JoinColumn({ name: 'order_id' })
  order: Order;

  @ManyToOne(() => Business, { nullable: true })
  @JoinColumn({ name: 'business_id' })
  business: Business;
}
