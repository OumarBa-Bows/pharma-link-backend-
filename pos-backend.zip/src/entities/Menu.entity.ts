import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from "typeorm"
import { Business } from "./Business.entity"
import { Category } from "./Category.entity"
import { MenuInfo } from "./MenuInfo.entity"

@Entity("menu")
export class Menu {
  @PrimaryGeneratedColumn()
  id!: number

  @Column({ type: "text" })
  name_ar!: string

  @Column({ type: "text", nullable: true })
  name_fr?: string

  @Column({ type: "text", nullable: true })
  description_fr?: string

  @Column({ type: "text", nullable: true })
  description_ar?: string

  @Column({ type: "double precision" })
  price!: number

  @ManyToOne(() => Category, { nullable: true })
  @JoinColumn({ name: "category_id" })
  category?: Category

  @Column({ type: "text", nullable: true })
  image_url?: string

  @ManyToOne(() => Business, { nullable: false, onDelete: "CASCADE" })
  @JoinColumn({ name: "business_id" })
  business!: Business

  @Column({ type: "boolean", default: true })
  is_available!: boolean

  @Column({ type: "uuid", default: () => "gen_random_uuid()" })
  code!: string

  @OneToMany(() => MenuInfo, (menuInfo) => menuInfo.menu)
  menuInfos!: MenuInfo[];
}
