// src/entities/PaymentType.ts

import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm"
import { Business } from "./Business.entity"
import { PaymentTypeMode } from "../enums/PaymentTypeMode"

@Entity("payment_types")
export class PaymentType {
  @PrimaryGeneratedColumn()
  id: number

  @Column()
  business_id: number

  @ManyToOne(() => Business, (business) => business.paymentTypes)
  @JoinColumn({ name: "business_id" })
  business: Business

  @Column({ type: "varchar", length: 20 })
  code: string

  @Column({ type: "text" })
  name_ar: string

  @Column({ type: "text" })
  name_fr: string

   @Column(

    {
        type: "enum",
        enum: PaymentTypeMode,
        nullable: true,
      }
   )
  type: PaymentTypeMode

  @Column({ type: "boolean", default: true, nullable: true })
  is_active: boolean | null

  @CreateDateColumn({ type: "timestamptz", name: "created_at", default: () => "now()" })
  created_at: Date

  @UpdateDateColumn({ type: "timestamptz", name: "updated_at", default: () => "now()" })
  updated_at: Date
}
