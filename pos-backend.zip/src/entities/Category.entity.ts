import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm"
import { Business } from "./Business.entity" 

@Entity("categories")
export class Category {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: "varchar", length: 255 })
  name_fr: string

  @Column({ type: "varchar", length: 255, nullable: true })
  name_ar?: string

  @CreateDateColumn({ type: "timestamp", name: "created_at", default: () => "CURRENT_TIMESTAMP" })
  created_at: Date

  @Column({ type: "boolean", default: true })
  status: boolean

  @ManyToOne(() => Business, { onDelete: "CASCADE" })
  @JoinColumn({ name: "business_id" })
  business: Business

  @Column({ type: "integer", default: 0 })
  display_order: number
}
