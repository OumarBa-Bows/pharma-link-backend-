import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  OneToMany,
} from "typeorm"
import { Business } from "./Business.entity"
import { OrderStatus } from "../enums/OrderStatus"
import { OrderType } from "../enums/OrderType"
import { Customer } from "./Customer.entity"
import { OrderPaymentStatus } from "../enums/OrderPaymentStatus"
import { OrdersOrigin } from "../enums/OrderOrigin"
import { OrderPayment } from "./OrdePayment.entity"




@Entity("orders")
@Index("idx_orders_business_ticket", ["id_business", "ticket_number"])
@Index("idx_orders_ticket_number", ["ticket_number"])
export class Order {
  @PrimaryGeneratedColumn()
  id!: number

  @Column({ type: "integer" })
  id_business!: number

  @ManyToOne(() => Business, { onDelete: "CASCADE" })
  @JoinColumn({ name: "id_business" })
  business!: Business

  @Column({ type: "enum", enum: OrderStatus, default: OrderStatus.PENDING })
  status!: OrderStatus

  @Column({ type: "numeric", precision: 10, scale: 2 })
  price!: number

  @Column({ type: "enum", enum: OrderType })
  type!: OrderType

  @CreateDateColumn({ type: "timestamptz", default: () => "now()" })
  created_at!: Date

  @UpdateDateColumn({ type: "timestamptz", default: () => "now()" })
  updated_at!: Date

  @Column({ type: "text", nullable: true })
  customer_phone?: string

  @ManyToOne(() => Customer, (c) => c.phone, { nullable: true })
  @JoinColumn({ name: "customer_phone", referencedColumnName: "phone" })
  customer?: Customer

  @Column({ type: "uuid", nullable: true })
  session_id?: string

  @Column({ type: "uuid", nullable: true })
  employe_id?: string

  @Column({ type: "enum", enum: OrderPaymentStatus, nullable: true, default: OrderPaymentStatus.UNPAID })
  payment_status?: OrderPaymentStatus

  @Column({ type: "double precision", nullable: true })
  delivery_fee?: number

  @Column({ type: "text", nullable: true })
  delivery_address?: string

  @Column({ type: "text", nullable: true })
  note?: string

  @Column({ type: "integer", nullable: true })
  delivery_id?: number|null

  @Column("text", { array: true, nullable: true })
  payment_screenshot?: string[]

  @Column({ type: "timestamptz", nullable: true })
  scheduled_at?: Date

  @Column({ type: "numeric", nullable: true })
  remaining_amount?: number

  @Column({ type: "geography", nullable: true })
  delivery_location?: any | null

  @Column({ type: "enum", enum: OrdersOrigin, nullable: true, default: OrdersOrigin.LIIVIPOS })
  origin?: OrdersOrigin

  @Column({ type: "timestamptz", nullable: true })
  customer_prefered_time?: Date

  @Column({ type: "integer", nullable: true })
  ticket_number?: number

  @Column({ type: "boolean", nullable: true,default: false })
  automatic_confirm?: boolean|false

  
  @OneToMany(() => OrderPayment, (orderPayment) => orderPayment.order)
  payments: OrderPayment[]
}
