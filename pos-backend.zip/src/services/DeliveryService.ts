import { QueryRunner } from "typeorm";
import { Order } from "../entities/Order.entity";
import { OrderItemInput } from "../interfaces/SharedType";
import { OrderType } from "../enums/OrderType";
import { DeliveryIntegration } from "../integrations/delivery/DeliveryIntegration";
import { OrderService } from "./OrderService";
import { DeliveryRequest } from "../integrations/delivery/type";
import { logger } from "../app";
import * as Sentry from "@sentry/node";

export class DeliveryService{

    static async  handleDeliveryChange(
    oldOrder: Order,
    updatedData: Order,
    deliveryData:DeliveryRequest,
    queryRunner: QueryRunner
    ) {
    

    try {
        const orderRepo =  queryRunner.manager.getRepository(Order)
        console.log("##BSNESS",oldOrder.business)
        const wasDelivery = oldOrder.type === OrderType.DELIVERY;
        const becomesDelivery = updatedData.type === OrderType.DELIVERY;
        logger.info(`IS WAS DELIVERY ${(oldOrder.delivery_id && wasDelivery && !becomesDelivery)}`)
        logger.info(`IS BECOME DELIVERY ${(!oldOrder.delivery_id && becomesDelivery && !wasDelivery)}`)

        if (oldOrder.delivery_id && wasDelivery && !becomesDelivery) {
           let isCancelled = false;
            try {
                  const deleteDelivery = await DeliveryIntegration.deleteDelivery(oldOrder.delivery_id);
            
                    isCancelled =true
            } catch (error) {
                Sentry.captureException(error);
                logger.info(`Delete Delivery failed is not waiting`)
                await DeliveryIntegration.cancelDelivery({
                    delivery_id:oldOrder.delivery_id
                })
                isCancelled =true;
            }
          
            if(isCancelled){
                updatedData.delivery_id=null
                updatedData.delivery_fee=0;
                updatedData.delivery_location=null

            }
       
        }
        if((updatedData.type==OrderType.DELIVERY && oldOrder.type!= OrderType.DELIVERY)){
            logger.info(`Create New Order delivery`)
            updatedData.business = oldOrder.business
            if(!deliveryData) throw new Error(`Delivery Data is not found for create a delivery`)
            const newDelivery = await OrderService.handleOrderDelivery(updatedData,deliveryData,queryRunner)   
        }

        updatedData =await queryRunner.manager.save(updatedData)
        return updatedData
    } catch (error) {
        Sentry.captureException(error);
        throw error
    }
   
    }

}