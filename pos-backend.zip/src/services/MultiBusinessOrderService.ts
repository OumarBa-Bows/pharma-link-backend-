import { AppDataSource, logger } from "../app";
import { GlobalKeys } from "../configs/GlobalKeys.config";
import { GlobalSettingValue } from "../configs/GlobalSettingValue";
import { redis } from "../configs/redis.config";
import { Business } from "../entities/Business.entity";
import { OrderPayment } from "../entities/OrdePayment.entity";
import { Order } from "../entities/Order.entity";
import { OrderItem } from "../entities/OrderItem.entity";
import { OrdersOrigin } from "../enums/OrderOrigin";
import { OrderPaymentStatus } from "../enums/OrderPaymentStatus";
import { OrderStatus } from "../enums/OrderStatus";
import { OrderType } from "../enums/OrderType";
import { PaymentStatus } from "../enums/PaymentStatus";
import { buildDeliveryPayload } from "../integrations/delivery/BuildDeliveryPayload";
import { DeliveryIntegration } from "../integrations/delivery/DeliveryIntegration";
import { CreateMultiBusinessOrderDTO } from "../interfaces/CreateMultiOrderBusinessDto";
import { CreateOrderWithItemssDTO } from "../interfaces/CreateOrderWithItemsDto";
import { applyDeliveryToOrder } from "../utils/delivery/order-delivery";
import { getOrderNotificationMessage } from "../utils/notifications/order-message";
import { sendWhatsAppMessage } from "../utils/notifications/send-whatsapp-message";
import { CustomerService } from "./CustomerService";
import { formatOrderCompositionMessage } from "./HelperService";
import { OrderReminderService } from "./OrderReminderService";
import { OrderService } from "./OrderService";
import * as Sentry from "@sentry/node";

export class MultiBusinessOrderService {
  static async createMultipleOrders(
    data: CreateMultiBusinessOrderDTO
  ): Promise<Order[]> {
    const createdOrders: Order[] = [];
    const orderItemsMap = new Map<number, any[]>();
    const queryRunner = AppDataSource.createQueryRunner();
    let deliveryId = null;
    let listBusiness: Business[] = [];

    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // First create orders without items
      for (const item of data.orders) {
        const businessOrder =
          await OrderService.createOrderWithoutItemsDeliveryAndReminder(
            item,
            queryRunner
          );
        createdOrders.push(businessOrder);
        // Store items for later
        orderItemsMap.set(businessOrder.id, item.items);
      }

      // Handle delivery if present
      if (createdOrders.length > 0 && data.deliveryData) {
        const orderDelivery = await this.handleOrderDelivery(
          createdOrders,
          data.deliveryData,
          queryRunner
        );
        if (orderDelivery.delivery_id) deliveryId = orderDelivery.delivery_id;
      }

      // Now save order items after delivery is created
      for (const order of createdOrders) {
        const items = orderItemsMap.get(order.id);
        if (items) {
          await OrderService.saveOrderItems(order, items, queryRunner);
        }
      }
      createdOrders.map(async (order) => {
        if (order.type == OrderType.DELIVERY) {
          await redis.set(
            `${GlobalKeys.PENDING_ORDER_KEY}${order.id}`,
            order.id,
            "EX",
            GlobalSettingValue.PENDING_ORDER_TTL
          );
        }
      });

      await queryRunner.commitTransaction();
      await this.sendNotificationForNotStartedBusiness(createdOrders);
      return createdOrders;
    } catch (error) {
      console.error("❌ Transaction failed:", error);
      Sentry.captureException(error);
      if (deliveryId) await DeliveryIntegration.deleteDelivery(deliveryId);

      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  static async handleOrderDelivery(
    orders: Order[],
    deliveryData: any,
    queryRunner: any
    // ou remplace par ton logger global
  ) {
    const updatedOrders: Order[] = [];

    const businessCode = orders.map((item) => item.business.code);
    logger.info("Mutiple business codes for adding delivery ", businessCode);

    const deliveryPayload = buildDeliveryPayload(
      orders[0],
      deliveryData,
      businessCode
    );
    logger.info(
      "Call Delivery Request From DeliveryIntegration Service",
      deliveryPayload
    );

    const delivery = await DeliveryIntegration.requestDelivery(deliveryPayload);

    if (delivery) {
      logger.info("Delivery ID received and sync with order:", delivery.id);
      for (const item of orders) {
        let order = applyDeliveryToOrder(item, delivery);
        logger.warn(`order ${JSON.stringify(order)}`);
        order = await queryRunner.manager.save(order);
        updatedOrders.push(order);
      }
    }
    return { updatedOrders: updatedOrders, delivery_id: delivery.id };
  }

  // static async sendNotificationForNotStartedBusiness(orders:Order[]){

  //   let listBusiness =  OrderService.getUniqueBusinessesFromOrders(orders);
  //   listBusiness.map(async(business)=>{
  //     if(!business.is_started){
  //       await sendWhatsAppMessage({
  //         message:"",
  //         phone:"",
  //         orderDetails:""
  //       })
  //     }
  //   })
  // }

  static async sendNotificationForNotStartedBusiness(orders: Order[]) {
    const listBusiness = OrderService.getUniqueBusinessesFromOrders(orders);

    for (const business of listBusiness) {
      if (!business.is_started) {
        const businessOrders = orders.filter(
          (o) =>
            o.id_business === business.id &&
            o.type == OrderType.DELIVERY &&
            o.origin != OrdersOrigin.LIIVIPOS
        );

        let message = `📦NOUVELLE COMMANDE -> DETAILS:\n`;

        for (const order of businessOrders) {
          const orderItems = await AppDataSource.manager.find(OrderItem, {
            where: { order_id: order.id },
          });

          const composition = await formatOrderCompositionMessage(orderItems);
          message += composition;
          getOrderNotificationMessage({
            origin: order.origin?? OrdersOrigin.LIIVIPOS,
            message: `${message} \n  ${order.note??""}` ,
            phone: business.whatsapp_number,
          });
        }
      }
    }
  }
}
