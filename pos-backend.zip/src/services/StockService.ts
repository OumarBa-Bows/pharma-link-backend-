import { QueryRunner } from "typeorm";
import { MenuItem } from "../entities/MenuItem.entity";
import { MenuInfo } from "../entities/MenuInfo.entity";
import { OrderItem } from "../entities/OrderItem.entity";
import { OrderItemInput } from "../interfaces/SharedType";
import { ProductType } from "../enums/ProductType";
import { Order } from "../entities/Order.entity";
import { OrdersOrigin } from "../enums/OrderOrigin";

export class StockService {

    static async updateOrderItems(
    orderId: number,
    items: OrderItemInput[],
    queryRunner: QueryRunner
  ): Promise<void> {
    const oldItems = await queryRunner.manager.find(OrderItem, {
      where: { order_id: orderId },
    });

    const order = await queryRunner.manager.findOneByOrFail(Order, { id: orderId });

    // Recalcul différentiel du stock
    await this.handleMenuItemConsumptionDiff(order, oldItems, items, queryRunner);

    // Mise à jour en base : suppression + insertion
    await queryRunner.manager.delete(OrderItem, { order_id: orderId });

    const newEntities = items.map((i) =>
      queryRunner.manager.create(OrderItem, {
        id_item: i.id_item,
        id_menu: i.id_menu,
        quantity: i.quantity,
        product_type: i.product_type,
        order_id: orderId,
      })
    );

    await queryRunner.manager.save(newEntities);
  }

  static async handleMenuItemConsumptionDiff(
    order: Order,
    oldItems: OrderItem[],
    newItems: OrderItemInput[],
    queryRunner: QueryRunner
  ): Promise<void> {
    const oldBreakdown = await this.getItemBreakdownFromOrderItems(oldItems, queryRunner);
    const newBreakdown = await this.getItemBreakdownFromOrderItems(newItems, queryRunner);

    const allItemIds = new Set([
      ...Array.from(oldBreakdown.keys()),
      ...Array.from(newBreakdown.keys()),
    ]);

    for (const itemId of allItemIds) {
      const oldQty = oldBreakdown.get(itemId) ?? 0;
      const newQty = newBreakdown.get(itemId) ?? 0;
      const delta = newQty - oldQty;

      if (delta !== 0) {
        await this.adjustStock(itemId, -delta,order.id_business, queryRunner, order.origin);
      }
    }
  }

  static async getItemBreakdownFromOrderItems(
    items: (OrderItem | OrderItemInput)[],
    queryRunner: QueryRunner
  ): Promise<Map<number, number>> {
    const breakdown = new Map<number, number>();

    for (const item of items) {
      if (item.product_type === ProductType.ITEM) {
        if(item.id_item){
            const existing = breakdown.get(item.id_item) ?? 0;
            breakdown.set(item.id_item, existing + item.quantity);
        }
     
      } else if (item.product_type === ProductType.MENU ) {
        const menuItems = await queryRunner.manager.find(MenuInfo, {
          where: { menu_id: item.id_menu },
        });

        for (const menuItem of menuItems) {
          const total = menuItem.quantity * item.quantity;
          const existing = breakdown.get(menuItem.item_id) ?? 0;
          breakdown.set(menuItem.item_id, existing + total);
        }
      }
    }

    return breakdown;
  }

  static async adjustStock(
    itemId: number,
    delta: number,
    businessId: number,
    queryRunner: QueryRunner,
    origin?: string
  ): Promise<void> {
    const product = await queryRunner.manager.findOneByOrFail(MenuItem, { id: itemId, business_id: businessId });

    const newQty = product.quantity + delta;

    // Skip stock validation for LIIVIPOS orders
    if (newQty < 0 && origin !== OrdersOrigin.LIIVIPOS) {
      throw new Error(`Stock insuffisant pour le produit ID ${itemId}`);
    }

    product.quantity = newQty;
    await queryRunner.manager.save(product);
  }
}