import { QueryRunner } from "typeorm";
import { Account } from "../entities/Account.entity";
import { logger } from "../app";
import { OperationNature } from "../enums/OperationNature";
import { Operation } from "../entities/Operation.entity";

export class OperationService{

    static  async  addTransaction(queryRunner:QueryRunner,data:{
        account:Account
        amount:number,
        nature:OperationNature,
        order_id?:number|null,
        business_id:number,
        reason?:string|null
    }){
            
            try {
                const accountRepository = queryRunner.manager.getRepository(Account);
                // Step1 : Update Account Balance
                logger.info(`Step2: Create Transaction for  userid ${data.account.type}`);
                
                const transactionRepository = queryRunner.manager.getRepository(Operation);
                let transaction = new Operation();
                transaction.amount = data.amount
                transaction.order_id = data.order_id??null;
                transaction.business_id = data.business_id;
                transaction.reason = data.reason??"";
                switch(data.nature){
                    case OperationNature.CASHIN:
                        logger.info(`Processing CASHIN Operation for amount ${data.amount}`);
                        transaction.balance_after_transaction=data.account.balance + data.amount;
                        transaction.balance_before_transaction = data.account.balance;
                        logger.info(`Processing CASHIN Operation -> NewBalance : ${transaction.balance_after_transaction}`);
                    
                        break;
                    case OperationNature.CASHOUT:
                         logger.info(`Processing CASHOUT Operation for amount ${data.amount}`);
                        transaction.balance_after_transaction=data.account.balance - data.amount;
                        transaction.balance_before_transaction = data.account.balance;
                         logger.info(`Processing CASHOUT Operation for amount ${data.amount} -> NewBalance : ${transaction.balance_after_transaction}`);
                         break;
                    default:
                        transaction.balance_after_transaction=data.account.balance+data.amount;
                        transaction.balance_before_transaction = data.account.balance;
                         logger.info(`Processing DEFAULT Operation for amount ${data.amount} -> NewBalance : ${transaction.balance_after_transaction}`);
                        break;
                }
                
                transaction.nature = data.nature;
              
                transaction.status = "valid";
                transaction.account_id = data.account.id
                transaction.business_id
                transaction = await transactionRepository.save(transaction);
                logger.info(`Operation created Success #TRID: ${transaction.id}`)
    
               data.account.balance=transaction.balance_after_transaction;
               
                await accountRepository.save(data.account);
                logger.info(`data.account : ${data.account.type} Balance updated OldBalance : ${transaction.balance_before_transaction} || NewBalance : ${transaction.balance_after_transaction}`)
                return transaction
            } catch (error) {
                logger.error(`addtransactionService Failed`)
                throw error
            }
    
    }

    static async orderPaymentTransaction(queryRunner:QueryRunner,data:{
        order_id?:number,
        amount:number,
        nature:OperationNature,
        business_id:number,
        reason?:string
    }){

        try {
            const accountRepository = queryRunner.manager.getRepository(Account);
            const cashAccount = await accountRepository.findOne({
                where:{business_id:data.business_id,type:"cash"}
            })
            if(!cashAccount) throw new Error(`Cash Account not found for this business ${data.business_id}`);

            const cashOperation =await this.addTransaction(queryRunner,{
                account:cashAccount,
                amount:data.amount,
                business_id:data.business_id,
                order_id:data.order_id??null,
                nature:data.nature??OperationNature.DEFAULT,
                reason:data.reason??null

            });
            return cashOperation;
        } catch (error) {
            throw error
        }
    }
}