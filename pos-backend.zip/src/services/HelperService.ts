import { Order } from "../entities/Order.entity" 
import { OrderItem } from "../entities/OrderItem.entity" 
import { MenuInfo } from "../entities/MenuInfo.entity" 
import { MenuItem } from "../entities/MenuItem.entity" 
import { QueryRunner } from "typeorm"
import { OrdersOrigin } from "../enums/OrderOrigin"
import { StockError } from "../Errors/StockError"
import { AppDataSource } from "../app"
import { ProductType } from "../enums/ProductType"
import { Menu } from "../entities/Menu.entity"



export async function formatOrderCompositionMessage(
  orderItems: OrderItem[],
): Promise<string> {
  let message = "";
  console.log("formatOrderCompositionMessage ",orderItems)
  for (const item of orderItems) {
    if (item.product_type == ProductType.ITEM) {
      const product = await AppDataSource.manager.findOneByOrFail(MenuItem, { id: item.id_item });
      message += `- 🍽️ ${product.name_fr} × ${item.quantity}\n`;
    }

    if (item.product_type === ProductType.MENU) {
      const menu = await AppDataSource.manager.findOneByOrFail(Menu, { id: item.id_menu });
      message += `- 🍽️ ${menu.name_fr} × ${item.quantity}\n`;

      
    }
  }

  return message;
}


export async function handleMenuItemConsumptionForDispatch(order: Order, queryRunner: QueryRunner): Promise<void> {
  const menuItemMap = new Map<number, number>(); // itemId → total quantity to consume

  if (!order.business.is_started) return;

  const orderItems = await queryRunner.manager.find(OrderItem, {
    where: { order_id: order.id },
  });

  for (const item of orderItems) {
    if (item.id_item) {
      menuItemMap.set(
        item.id_item,
        (menuItemMap.get(item.id_item) || 0) + item.quantity
      );
    } else if (item.id_menu) {
      const menuInfos = await queryRunner.manager.find(MenuInfo, {
        where: { menu_id: item.id_menu },
      });

      for (const mi of menuInfos) {
        if (!mi.item_id) continue;
        const consumedQty = (mi.quantity || 1) * item.quantity;

        menuItemMap.set(
          mi.item_id,
          (menuItemMap.get(mi.item_id) || 0) + consumedQty
        );
      }
    }
  }

  const itemIds = Array.from(menuItemMap.keys());

  // 1. Charger tous les MenuItem d’un coup
  const menuItems = await queryRunner.manager.findByIds(MenuItem, itemIds);

  const menuItemById = new Map<number, MenuItem>();
  for (const item of menuItems) {
    menuItemById.set(item.id, item);
  }

  // 2. Vérification stock (si origine ≠ LIIVIPOS)
  if (order.origin !== OrdersOrigin.LIIVIPOS) {
    for (const [itemId, qtyToConsume] of menuItemMap.entries()) {
      const menuItem = menuItemById.get(itemId);
      if (!menuItem) continue;

      if (menuItem.is_inventory_tracked) {
        const currentStock = menuItem.quantity || 0;
        // if (currentStock < 5) {
        //   throw new StockError(
        //     `Stock threshold reached for item ${menuItem.name_fr} (available: ${currentStock})`,
        //     {
        //       business_name_ar: order.business.business_name_ar,
        //       business_name_fr: order.business.business_name_fr,
        //     }
        //   );
        // }
        // if (currentStock < qtyToConsume) {
        //   throw new StockError(
        //     `Insufficient stock for item ${menuItem.name_fr} (required: ${qtyToConsume}, available: ${currentStock})`,
        //     {
        //       business_name_ar: order.business.business_name_ar,
        //       business_name_fr: order.business.business_name_fr,
        //     }
        //   );
        // }
      }
    }
  }

  // 3. Application des décréments (1 seule boucle)
  for (const [itemId, qtyToDeduct] of menuItemMap.entries()) {
    const menuItem = menuItemById.get(itemId);
    if (!menuItem) continue;

    if (menuItem.is_inventory_tracked) {
      await queryRunner.manager.update(
        MenuItem,
        { id: itemId, business_id: order.business.id },
        {
          quantity: () => `quantity - ${qtyToDeduct}`,
        }
       
      );
    }
  }
}

export async function handleMenuItemConsumption(order: Order, queryRunner: QueryRunner): Promise<void> {
  const menuItemMap = new Map<number, number>(); // itemId → total quantity to consume

  if (!order.business.is_started) return;

  const orderItems = await queryRunner.manager.find(OrderItem, {
    where: { order_id: order.id },
  });

  for (const item of orderItems) {
    if (item.id_item) {
      menuItemMap.set(
        item.id_item,
        (menuItemMap.get(item.id_item) || 0) + item.quantity
      );
    } else if (item.id_menu) {
      const menuInfos = await queryRunner.manager.find(MenuInfo, {
        where: { menu_id: item.id_menu },
      });

      for (const mi of menuInfos) {
        if (!mi.item_id) continue;
        const consumedQty = (mi.quantity || 1) * item.quantity;

        menuItemMap.set(
          mi.item_id,
          (menuItemMap.get(mi.item_id) || 0) + consumedQty
        );
      }
    }
  }

  const itemIds = Array.from(menuItemMap.keys());

  // 1. Charger tous les MenuItem d’un coup
  const menuItems = await queryRunner.manager.findByIds(MenuItem, itemIds);

  const menuItemById = new Map<number, MenuItem>();
  for (const item of menuItems) {
    menuItemById.set(item.id, item);
  }

  // 2. Vérification stock (si origine ≠ LIIVIPOS)
  if (order.origin !== OrdersOrigin.LIIVIPOS) {
    for (const [itemId, qtyToConsume] of menuItemMap.entries()) {
      const menuItem = menuItemById.get(itemId);
      if (!menuItem) continue;

      // if (menuItem.is_inventory_tracked) {
      //   const currentStock = menuItem.quantity || 0;
      //   if (currentStock < 5) {
      //     throw new StockError(
      //       `Stock threshold reached for item ${menuItem.name_fr} (available: ${currentStock})`,
      //       {
      //         business_name_ar: order.business.business_name_ar,
      //         business_name_fr: order.business.business_name_fr,
      //       }
      //     );
      //   }
      //   if (currentStock < qtyToConsume) {
      //     throw new StockError(
      //       `Insufficient stock for item ${menuItem.name_fr} (required: ${qtyToConsume}, available: ${currentStock})`,
      //       {
      //         business_name_ar: order.business.business_name_ar,
      //         business_name_fr: order.business.business_name_fr,
      //       }
      //     );
      //   }
      // }
    }
  }

  // 3. Application des décréments (1 seule boucle)
  // for (const [itemId, qtyToDeduct] of menuItemMap.entries()) {
  //   const menuItem = menuItemById.get(itemId);
  //   if (!menuItem) continue;

  //   if (menuItem.is_inventory_tracked) {
  //     await queryRunner.manager.update(
  //       MenuItem,
  //       { id: itemId, business_id: order.business.id },
  //       {
  //         quantity: () => `quantity - ${qtyToDeduct}`,
  //       }
       
  //     );
  //   }
  // }
}