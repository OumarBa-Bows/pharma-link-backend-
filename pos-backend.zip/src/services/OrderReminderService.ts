;
import { AppDataSource, logger } from "../app";
import { GlobalKeys } from "../configs/GlobalKeys.config";
import { GlobalSettingValue } from "../configs/GlobalSettingValue";
import { redis } from "../configs/redis.config";
import { Order } from "../entities/Order.entity";
import { OrderJob } from "../entities/OrderJob.entity"; 
import { OrderJobStatus } from "../enums/OrderJobStatus";
import { dateToCronSpec, generateJobConfig, generateJobName } from "../utils/jenkins/generate-job-config";
import { jenkins } from "../utils/jenkins/jenkins";
import * as Sentry from "@sentry/node";

export class OrderReminderService {

    /**
     * Creates an order reminder job for the specified order.
     * @param {number} orderId - The ID of the order to create a reminder for.
     * @returns {Promise<OrderJob>} The created order job.
     * @throws {Error} If the orderId is missing or the order is not found.
     */
    static async createOrderReminder(orderId: number) {
      logger.info(`Creating order reminder for orderId: ${orderId}`);
        if (!orderId) throw new Error("Missing orderId");

        const orderRepo = AppDataSource.getRepository(Order);
        const orderJobRepo = AppDataSource.getRepository(OrderJob);

        const order = await orderRepo.findOne({ where: { id: orderId } });
        if (!order) throw new Error("Order not found");

        const orderJobName = generateJobName(orderId);
        const orderJob = orderJobRepo.create({
        name: orderJobName,
        order_id: order.id,
        business_id: order.id_business,
        job_status: OrderJobStatus.STARTED,
        });

        const savedOrderJob = await orderJobRepo.save(orderJob);
        logger.info(`Order reminder job created with ID: ${savedOrderJob.id}`);

        return savedOrderJob;
    }


    static async scheduleReminder(
    orderId: string | number,
    reminderTime: any,
    orderData: Record<string, any>
  ) {
    try {
      // Validate input
      if (!orderId || !reminderTime || !orderData) {
        throw new Error("Missing required fields: orderId, reminderTime, or orderData");
      }

      // Parse the reminder time
      const reminderDate = new Date(reminderTime);
      const currentDate = new Date();

      // Validate the reminder time (not in the past and not more than 24h in the future)
      if (reminderDate <= currentDate) {
        throw new Error("Reminder time cannot be in the past");
      }

      const twentyFourHoursLater = new Date(currentDate);
      twentyFourHoursLater.setHours(currentDate.getHours() + 24);

      if (reminderDate > twentyFourHoursLater) {
        throw new Error("Reminder time cannot be more than 24 hours in the future");
      }

      // Vérifie que la commande existe
      const orderRepo = AppDataSource.getRepository(Order);
      const order = await orderRepo.findOne({ where: { id: Number(orderId) } });
      if (!order) throw new Error("Order not found");

      // Génère la config Jenkins
      const jobName = generateJobName(orderId);
      
      const cronSpec = dateToCronSpec(reminderDate);
      const jobConfig = generateJobConfig(cronSpec, orderId, orderData);

      // Crée ou met à jour le job Jenkins
      try {
        const job = await jenkins.job.get(jobName); // Check if the job exists
        if (job) {
          
          await jenkins.job.config(jobName, jobConfig); 
        }else{
          await jenkins.job.create(jobName, jobConfig); // Update the job configuration
        }
        
      } catch (error) {
        Sentry.captureException(error);
       
      }

      return {
        success: true,
        message: `Reminder scheduled for ${reminderDate.toISOString()}`,
        jobName,
      };
    } catch (error: any) {
      Sentry.captureException(error);
      console.error("Error scheduling reminder:", error);
      return {
        success: false,
        message: "Failed to schedule reminder",
        jobName: "undefined",
        error: error.message,
      };
    }
  }

    static async scheduleReminderRedis(
    orderId: string | number,
    reminderTime: any,
    orderData: Record<string, any>
  ) {
    try {
      // Validate input
      if (!orderId || !reminderTime || !orderData) {
        throw new Error("Missing required fields: orderId, reminderTime, or orderData");
      }

      // Parse the reminder time
      const reminderDate = new Date(reminderTime);
      const currentDate = new Date();

      // Validate the reminder time (not in the past and not more than 24h in the future)
      if (reminderDate <= currentDate) {
        throw new Error("Reminder time cannot be in the past");
      }

      const twentyFourHoursLater = new Date(currentDate);
      twentyFourHoursLater.setHours(currentDate.getHours() + 24);

      if (reminderDate > twentyFourHoursLater) {
        throw new Error("Reminder time cannot be more than 24 hours in the future");
      }

      // Vérifie que la commande existe
      const orderRepo = AppDataSource.getRepository(Order);
      const order = await orderRepo.findOne({ where: { id: Number(orderId) } });
      if (!order) throw new Error("Order not found");

      const reminderDateTime = new Date(reminderTime); // 2025-07-08T14:57:00Z
      const currentDateTime = new Date(); // Date actuelle

      const ttlInSeconds = Math.floor((reminderDateTime.getTime() - currentDateTime.getTime()) / 1000);
      logger.info(`Scheduling reminder for order ${orderId} with TTL: ${ttlInSeconds} seconds`);

      // Génère la config Jenkins
      await redis.set(`${GlobalKeys.SCHEDULED_ORDER_KEY}${order.id}`, order.id, "EX", ttlInSeconds);
        return {
        success: true,
        message: `Reminder scheduled for ${order.id} `,
        
      };
      } catch (error) {
        Sentry.captureException(error);
        logger.error("Error scheduling reminder in Redis:", error);
       
      }

      
    } 


     static async createOrderReminderRedis(orderId: number,status:OrderJobStatus) {
      logger.info(`Creating order reminder for orderId: ${orderId}`);
        if (!orderId) throw new Error("Missing orderId");

        const orderRepo = AppDataSource.getRepository(Order);
        const orderJobRepo = AppDataSource.getRepository(OrderJob);

        const order = await orderRepo.findOne({ where: { id: orderId } });
        if (!order) throw new Error("Order not found");
        const orderJobName = generateJobName(orderId);
       
        const orderJob = orderJobRepo.create({
        name: orderJobName,
        order_id: order.id,
        business_id: order.id_business,
        job_status: status??OrderJobStatus.STARTED,
        });

        const savedOrderJob = await orderJobRepo.save(orderJob);
        logger.info(`Order reminder job created with ID: ${savedOrderJob.id}`);

        return savedOrderJob;
    }
}
