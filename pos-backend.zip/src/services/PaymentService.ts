import { QueryRunner } from "typeorm";
import { PaymentDto } from "../interfaces/PaymentDto";
import { OrderPayment } from "../entities/OrdePayment.entity";
import { OrderService } from "./OrderService";
import { Order } from "../entities/Order.entity";
import { PaymentStatus } from "../enums/PaymentStatus";
import { OperationService } from "./OperationService";
import { OperationNature } from "../enums/OperationNature";
import {  PaymentTypeMode } from "../enums/PaymentTypeMode";
import { PaymentType } from "../entities/PaymentType.entity";
import { OrderPaymentStatus } from "../enums/OrderPaymentStatus";
import { logger } from "../app";

export class PaymentService{

    static async addNewPaymentwithOperation(queryRunner:QueryRunner,data:{
        payment:PaymentDto,
        orderId:number
    }){
        const orderRepo = queryRunner.manager.getRepository(Order);
        let order = await orderRepo.findOne({
            where:{id:data.orderId}
        });
        if(!order) throw new Error(`Order not Found to process payment `);

        let remaining = order.remaining_amount??order.price

        const newPayment = queryRunner.manager.create(OrderPayment, {
                  payment_type_id: data.payment.payment_type_id,
                  amount: data.payment.amount,
                  order_id: data.orderId,
                  business_id: order.id_business,
                  status: data.payment.payment_status ?? PaymentStatus.VALIDED,
                });
        
               
        await queryRunner.manager.save(newPayment);
        if(data.payment.type == PaymentTypeMode.CASH){
             await OperationService.orderPaymentTransaction(queryRunner,{
            amount:newPayment.amount,
            business_id:order.id_business,
            nature:OperationNature.CASHIN,
            order_id:order.id
        })
        }
       
        // order.remaining_amount = remaining - data.payment.amount;
        // order =await orderRepo.save(order);

        return {newPayment:newPayment,order:order};

    }

    static async addPayment(queryRunner:QueryRunner,data:{
            orderId: number, businessId: number,
            payment_type_id: number, 
            amount: number
        }) {
    if (!data.orderId) {
      throw new Error("Order ID is required");
    }
    if (!data.payment_type_id || !data.amount || data.amount <= 0) {
        throw new Error("Valid payment_type_id and positive amount are required");
      
    }

    try {
      const orderRepo = queryRunner.manager.getRepository(Order);
      const paymentRepo = queryRunner.manager.getRepository(OrderPayment);
      const paymentTypeRepo = queryRunner.manager.getRepository(PaymentType);

      // 1. Vérifier la commande
      const order = await orderRepo.findOne({
        where: { id: data.orderId, id_business: data.businessId }
      });
      if (!order) throw new Error("Order not found or access denied");

      // 2. Vérifier le type de paiement
      const paymentType = await paymentTypeRepo.findOne({
        where: { id: data.payment_type_id, business_id: data.businessId, is_active: true },
      });
      if (!paymentType) throw new Error("Invalid or inactive payment type");
    
      // 3. Calcul du restant
    //   const totalPaid = order.payments
    //     .filter((p) => p.status !== "CANCELLED")
    //     .reduce((sum, p) => sum + Number(p.amount), 0);

      const remaining = Number(order.remaining_amount??order.price) ;
      if (data.amount > remaining) {
        throw new Error(`Amount exceeds remaining balance (${remaining} MRU)`);
      }

      // 4. Créer le paiement
    //   const payment = paymentRepo.create({
    //     order_id: data.orderId,
    //     amount:data.amount,
    //     payment_type_id:data.payment_type_id,
    //     business_id: data.businessId,
    //   });
    //   await paymentRepo.save(payment);
       if (!paymentType.type) throw new Error("this payment type has no defined mode (CASH or WALLET)");

        const payment = await this.addNewPaymentwithOperation(queryRunner,{
            payment:{amount:data.amount,payment_type_id:data.payment_type_id,type:paymentType.type},
            orderId:data.orderId,
        
            
        })

      // 5. Mettre à jour la commande
      const newTotal = remaining ;
      const newRemaining =  Number(order.remaining_amount??order.price) -data.amount; ;;

      order.payment_status =
        newRemaining <= 0 ? OrderPaymentStatus.PAID: newTotal > 0 ? OrderPaymentStatus.PARTIAL_PAID : OrderPaymentStatus.UNPAID;
      order.remaining_amount = Math.max(0, newRemaining);

      await orderRepo.save(order);

      // 6. Commit transaction
    //   await queryRunner.commitTransaction();

      return {
        success: true,
        data: {
          payment:payment.newPayment,
          newPaymentStatus: order.payment_status,
          remainingAmount: order.remaining_amount,
        },
      };
    } catch (err) {
      // rollback si erreur
    //   await queryRunner.rollbackTransaction();
      throw err;
    } 
  }


    static async cancelPayment(queryRunner:QueryRunner,data:{
            orderId: number, businessId: number,
            order_payment_id: number
        }) {
    if (!data.orderId) {
      throw new Error("Order ID is required");
    }


    try {
        const orderRepo = queryRunner.manager.getRepository(Order);
        const paymentRepo = queryRunner.manager.getRepository(OrderPayment);

        // 1. Vérifier la commande
        const order = await orderRepo.findOne({
            where: { id: data.orderId, id_business: data.businessId }
        });
        if (!order) throw new Error("Order not found or access denied");

        // 2. Vérifier le type de paiement
        const orderPayment = await paymentRepo.findOne({
            where: { id: data.order_payment_id, order_id: data.orderId,status:PaymentStatus.VALIDED },
            relations:["paymentType"]
        });
        if (!orderPayment) throw new Error("Not Found Validated Payment to cancel");

        if (!orderPayment.paymentType.type) throw new Error("this payment type has no defined mode (CASH or WALLET)");

     
        // Manage Remaining order amount and update payment status
        logger.info(`Old Remaining Amount ${order.remaining_amount} for order ${order.id}`);
        logger.info(`Cancelling payment of amount ${orderPayment.amount} for order ${order.id}`);
        const oldRemaining = Number(order.remaining_amount ?? order.price);
        const newRemaining = oldRemaining + Number(orderPayment.amount);
        order.payment_status =
        newRemaining <= 0
            ? OrderPaymentStatus.PAID
            : newRemaining < order.price
            ? OrderPaymentStatus.PARTIAL_PAID
            : OrderPaymentStatus.UNPAID;

        order.remaining_amount = Math.max(0, newRemaining);
      await orderRepo.save(order);
        orderPayment.status = PaymentStatus.CANCELLED;
        await paymentRepo.save(orderPayment);

        if(orderPayment.paymentType.type == PaymentTypeMode.CASH){
             await OperationService.orderPaymentTransaction(queryRunner,{
            amount:orderPayment.amount,
            business_id:order.id_business,
            nature:OperationNature.CASHOUT,
            order_id:order.id
        })
        }
      return {
        success: true,
        data: {
          payment:orderPayment,
          newPaymentStatus: order.payment_status,
          remainingAmount: order.remaining_amount,
        },
      };
    } catch (err) {
     
      throw err;
    } 
  }
}