import { AppDataSource, supabase, supabaseLiviiPos } from "../app";
import { Business } from "../entities/Business.entity";

export class ProductEstimatedService {


    static async getProductEstimatedDeliveryTime(business_id: number) {
  try {
    const business = await AppDataSource.manager
      .getRepository(Business)
      .findOneByOrFail({ id: business_id });

    // 1. Charger les items disponibles
    const { data: products } = await supabaseLiviiPos
      .from("product_quantities_infos")
      .select("*")
      .eq("business_id", business.id);



    return {
      menu: products,
    };
  } catch (error) {
    throw error;
  }
    }





}