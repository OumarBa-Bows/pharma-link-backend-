import { QueryRunner } from "typeorm";
import { AppDataSource } from "../app";
import { Customer } from "../entities/Customer.entity";
import { MessageLanguage } from "../enums/MessageLanguage";

export class CustomerService {
  static async addCustomer(data: Partial<Customer>): Promise<Customer> {
    const repo = AppDataSource.getRepository(Customer);
    const customer = repo.create(data);
    return await repo.save(customer);
  }

  static async findCustomer(criteria: Partial<Customer>): Promise<Customer | null> {
    const repo = AppDataSource.getRepository(Customer);
    return await repo.findOne({ where: criteria });
  }

  static async findOrCreateCustomer(data: Partial<Customer>,queryRunner:QueryRunner): Promise<Customer> {
    const repo = queryRunner.manager.getRepository(Customer);
    let customer = await repo.findOne({ where: data });
    if (!customer) {
      customer = repo.create(data);
      customer = await queryRunner.manager.save(customer);
    }
    return customer;
  }

   static async updateCustomerLang(data:{phone:string,lang:MessageLanguage}){

    const customerRepository = AppDataSource.getRepository(Customer);
    const customer = await customerRepository.findOne({
        where: { phone: data.phone }
    });
    if(!customer) throw new Error(`Customer Not found`)
    customer.prefered_language = data.lang??customer?.prefered_language
    await customerRepository.save(customer);
    return true;
  }
}