import { AppDataSource, logger, supabaseLiviiPos } from "../app";
import { GlobalKeys } from "../configs/GlobalKeys.config";
import { redis } from "../configs/redis.config";
import { ItemVirtualAvailability } from "../entities/ItemVirtualAvailabilty.entity";
import { MenuItem } from "../entities/MenuItem.entity";
import { ItemPreparationStatus } from "../enums/ItemPreparationStatus";
import { CreateItemVirtualAvailabilityDto, UpdateItemVirtualAvailabilityDto } from "../interfaces/CreateVirtualAvailabilityDto";
import * as Sentry from "@sentry/node";
export class ItemAvailabilityService {

    static async createVirtualAvailability(data: CreateItemVirtualAvailabilityDto): Promise<ItemVirtualAvailability> {

         const queryRunner = AppDataSource.createQueryRunner();
      await queryRunner.connect();
      await queryRunner.startTransaction();
      try{
         data.status = data.status || ItemPreparationStatus.IN_PREPARATION;
          const virtualItemRepo = queryRunner.manager.getRepository(ItemVirtualAvailability);
          const menuItemRepo = queryRunner.manager.getRepository(MenuItem);
        
          const menuItem = await menuItemRepo.findOne({
            where: {
              id: data.menu_item_id,
              is_inventory_tracked: true,
              business_id:data.business_id
            },

            lock: { mode: "pessimistic_write" },
          });

        
          if(!menuItem) throw new Error(`Menu item with ID ${data.menu_item_id} not found or not inventory tracked`);
          //  const virtualItem = virtualItemRepo.create(data);
             const availability = virtualItemRepo.create(data);
        const virtualItem = await virtualItemRepo.save(availability);;
          menuItem.dailly_quantity = (menuItem.dailly_quantity??0) + virtualItem.quantity;

          await menuItemRepo.save(menuItem);
          await queryRunner.commitTransaction();
          await this.scheduleVirtualPrepTimeRedis(virtualItem.id, virtualItem.prepartion_time);
          return virtualItem;
      }catch(error){
        await queryRunner.rollbackTransaction();
        
        throw error;
      }finally{
        await queryRunner.release();
      }

    }

    static async scheduleVirtualPrepTimeRedis(
    virtual_item_id: string | number,
    prepartion_time: number,
  ) {
    try {
      // Validate input
      if (!virtual_item_id || !prepartion_time) {
        throw new Error("Missing required fields: virtual_item_id, reminderTime");
      }

      // Parse the prepartion_time
      
      const currentDate = new Date();


      const prepTime = new Date(currentDate);
      prepTime.setMinutes(currentDate.getMinutes() + prepartion_time);

      console.log("prepTime ready at ", prepTime);

      // Vérifie que la commande existe
      const virtual_item_repo = AppDataSource.getRepository(ItemVirtualAvailability);
      const virtual_item = await virtual_item_repo.findOne({ 
        where: { 
            id: Number(virtual_item_id),
            status:ItemPreparationStatus.IN_PREPARATION

        } 
    });
      if (!virtual_item) throw new Error("virtual_item not found");

      const currentDateTime = new Date(); // Date actuelle

      const ttlInSeconds = Math.floor((prepTime.getTime() - currentDateTime.getTime()) / 1000);
      logger.info(`Scheduling reminder for virtual item qty ${virtual_item_id} with TTL: ${ttlInSeconds} seconds`);

      // Génère la config Jenkins
      await redis.set(`${GlobalKeys.VIRTUAL_ITEM_PREP_KEY}${virtual_item_id}`, virtual_item_id, "EX", ttlInSeconds);
      virtual_item.available_at = prepTime;
      await virtual_item_repo.save(virtual_item);
      return {
        success: true,
        message: `Reminder scheduled for ${virtual_item.id} `,
        
      };
      } catch (error) {
        Sentry.captureException(error);
        logger.error("Error scheduling reminder in Redis:", error);
        
      }

      
    }
    
    static async completeVirtualAvailability(virtual_item_id:number): Promise<ItemVirtualAvailability | null> {

      const queryRunner = AppDataSource.createQueryRunner();
      await queryRunner.connect();
      await queryRunner.startTransaction();
      try{
          const virtualItemRepo = queryRunner.manager.getRepository(ItemVirtualAvailability);
          const menuItemRepo = queryRunner.manager.getRepository(MenuItem);
          let virtualItem = await virtualItemRepo.findOne({
            where: {
              id: virtual_item_id,
              status: ItemPreparationStatus.IN_PREPARATION,
            },

            lock: { mode: "pessimistic_write" },
          });
          if(!virtualItem) throw new Error(`Virtual item with ID ${virtual_item_id} not found or not in preparation status`);

          const menuItem = await menuItemRepo.findOne({
            where: {
              id: virtualItem.menu_item_id,
              is_inventory_tracked: true,
            },

            lock: { mode: "pessimistic_write" },
          });

          virtualItem.status = ItemPreparationStatus.READY;
        
          if(!menuItem) throw new Error(`Menu item with ID ${virtualItem.menu_item_id} not found or not inventory tracked`);
          
          logger.info(`Completing virtual availability for item ID: ${virtual_item_id} and adding quantity to menu item ID: ${menuItem.id}`);
          menuItem.quantity += virtualItem.quantity;
        
          virtualItem = await virtualItemRepo.save(virtualItem);
          await menuItemRepo.save(menuItem);
          
          await queryRunner.commitTransaction();
          await redis.del(`${GlobalKeys.VIRTUAL_ITEM_PREP_KEY}${virtual_item_id}`)
          return virtualItem;
      }catch(error){
        await queryRunner.rollbackTransaction();
        Sentry.captureException(error);
        logger.error("Error completing virtual availability:", error);
        return null;
      }finally{
        await queryRunner.release();
      }
    }

    static async getVirtualItmesInPreparation(data:{business_id:number}){
      const trackableInfo = this.getTrackableItemsInfo(data.business_id)
      return trackableInfo;
    }

  static async getTrackableItemsInfo(businessId:number) {
  try {

    // Get the current user and extract businessId

    if (!businessId) throw new Error("Business ID not found");

    const { data:inventoriesItem, error } = await supabaseLiviiPos
      .from("menu_item")
      .select("*")
      .eq("business_id", businessId)
      .eq("is_inventory_tracked", true);

    if (error) {
      throw error;
    }

    const { data:virtualInventoriesItems, error:virtualError } = await supabaseLiviiPos
      .from("item_availability_view")
      .select("*")
      .eq("business_id", businessId)
      .eq("status", "IN_PREPARATION")
      .eq("is_inventory_tracked", true)
      .order("available_at", { ascending: true });

    if (error) {
      throw virtualError;
    }
    return {inventoriesItem:inventoriesItem??[],virtualInventoriesItems:virtualInventoriesItems??[]};
  } catch (error) {
    throw error;
  }
}

 static async editVirtualAvailability(data: UpdateItemVirtualAvailabilityDto): Promise<ItemVirtualAvailability> {
       
      const queryRunner = AppDataSource.createQueryRunner();
      await queryRunner.connect();
      await queryRunner.startTransaction();
      try {
        const virtualItemRepo = queryRunner.manager.getRepository(ItemVirtualAvailability);
        const menuItemRepo = queryRunner.manager.getRepository(MenuItem);
        let virtualItem = await virtualItemRepo.findOne({
          where: {
            id: data.id,
            status: ItemPreparationStatus.IN_PREPARATION,
          },

          lock: { mode: "pessimistic_write" },
        });
        if(!virtualItem) throw new Error(`Virtual item with ID ${data.id} not found or not in preparation status`);

        let menuItem = await menuItemRepo.findOne({
          where: {
            id: virtualItem.menu_item_id,
            // is_inventory_tracked: true,
          }
        });
        if(!menuItem) throw new Error(`Menu item with ID ${virtualItem.menu_item_id} not found`);

        const  oldVirtualQuantity = virtualItem.quantity;
        await redis.del(`${GlobalKeys.VIRTUAL_ITEM_PREP_KEY}${virtualItem.id}`)
        
        menuItem.dailly_quantity = (menuItem.dailly_quantity??0 )- oldVirtualQuantity + data.quantity;
        virtualItem.prepartion_time = data.prepartion_time;
        virtualItem.quantity = data.quantity;
        virtualItem = await virtualItemRepo.save(virtualItem);
        menuItem = await menuItemRepo.save(menuItem);
        logger.info(`Edited virtual availability for item ID: ${data.id} and updated menu item ID: ${menuItem.id}`);
        await queryRunner.commitTransaction();
        this.scheduleVirtualPrepTimeRedis(virtualItem.id, virtualItem.prepartion_time);
        return virtualItem;
      } catch (error) {
        await queryRunner.rollbackTransaction();
       
        logger.error("Error editing virtual availability:", error);
        throw error;
      }finally{
        await queryRunner.release();
      }
        

    }

    
       
}