import { QueryRunner } from "typeorm"
import { AppDataSource, logger, supabase, supabaseLiviiPos } from "../app"
import * as Sentry from "@sentry/node"
import { Business } from "../entities/Business.entity"
import { Customer } from "../entities/Customer.entity"
import { OrderPayment } from "../entities/OrdePayment.entity"
import { Order } from "../entities/Order.entity"
import { OrderItem } from "../entities/OrderItem.entity"
import { OrdersOrigin } from "../enums/OrderOrigin"
import { OrderPaymentStatus } from "../enums/OrderPaymentStatus"
import { OrderStatus } from "../enums/OrderStatus"
import { OrderType } from "../enums/OrderType"
import { PaymentStatus } from "../enums/PaymentStatus"
import { buildDeliveryPayload } from "../integrations/delivery/BuildDeliveryPayload"
import { DeliveryIntegration } from "../integrations/delivery/DeliveryIntegration"
import { CreateOrderWithItemssDTO } from "../interfaces/CreateOrderWithItemsDto"
import { applyDeliveryToOrder } from "../utils/delivery/order-delivery"
import { CustomerService } from "./CustomerService"
import { OrderReminderService } from "./OrderReminderService"
import { CreateOrderPayload, OrderItemInput } from "../interfaces/SharedType"
import { handleMenuItemConsumption, handleMenuItemConsumptionForDispatch } from "./HelperService"
import { BusinessStateError } from "../Errors/BusinnessStateError"
import { UpdateOrderPayload } from "../interfaces/UpdateOrderPayload"
import { it } from "node:test"
import { StockService } from "./StockService"
import { ProductType } from "../enums/ProductType"
import { MenuItem } from "../entities/MenuItem.entity"
import { MenuInfo } from "../entities/MenuInfo.entity"
import { DeliveryService } from "./DeliveryService"
import { MultiBusinessOrderService } from "./MultiBusinessOrderService"
import { n8nSendMessageToOperationChanel, n8nSendMessageToShereeqChanel } from "../utils/n8n-webhook"
import { OperationService } from "./OperationService"
import { OperationNature } from "../enums/OperationNature"
import {  PaymentTypeMode } from "../enums/PaymentTypeMode"

export class OrderService {


  static async createOrderWithoutItemsDeliveryAndReminder(data: CreateOrderPayload,queryRunner:QueryRunner): Promise<Order> {


  try {
    const business = await queryRunner.manager.findOne(Business, {
      where: { id: data.order.id_business },
    });
    if (!business) {
      throw new Error("Business not found for the provided order");
    }
    const businessNotAbleToCommand = !business.is_open && [OrdersOrigin.DEJAJAPP, OrdersOrigin.LIVIIAPP].includes(data.order.origin as OrdersOrigin);
    if (businessNotAbleToCommand) {
      throw new BusinessStateError(`Sorry Business Is Closed Now`,business)
    }

    // verify or create customer
    if (data.order.customer_phone) {
      await CustomerService.findOrCreateCustomer(
        { phone: data.order.customer_phone },
        queryRunner
      );
    }

    // Création de la commande
    const order = queryRunner.manager.create(Order, data.order);

    if (data.order.scheduled_at || data.order.origin != OrdersOrigin.LIIVIPOS) {
      data.order.status = OrderStatus.PENDING;
    }
    else if(data.order.origin == OrdersOrigin.LIIVIPOS){
      data.order.status =data.order.status?? OrderStatus.ACCEPTED;
    }

    order.remaining_amount = data.order.price || 0;
    let savedOrder = await queryRunner.manager.save(order);

    let remaining_amount = savedOrder.price;

    if (Array.isArray(data.paymentData) && data.paymentData.length > 0) {
      const paymentDatas = data.paymentData.map((item) => {
        remaining_amount = remaining_amount - item.amount;
        return queryRunner.manager.create(OrderPayment, {
          payment_type_id: item.payment_type_id,
          order_id: savedOrder.id,
          amount: item.amount,
          business_id: savedOrder.id_business,
          status: item.payment_status ?? PaymentStatus.VALIDED,
        });
      });
      await queryRunner.manager.save(paymentDatas);
    }

    savedOrder.remaining_amount = remaining_amount;
    savedOrder.payment_status =
      remaining_amount > 0 ? OrderPaymentStatus.UNPAID : OrderPaymentStatus.PAID;
    savedOrder.business=business;

     const { data:ticket_number, error } = await supabaseLiviiPos
         .rpc("get_next_business_ticket", {business_id:business.id });
     
    if(ticket_number){
      savedOrder.ticket_number =ticket_number+1;
      savedOrder = await queryRunner.manager.save(savedOrder);

       const {  error } = await supabaseLiviiPos
         .rpc("assign_ticket_number", {business_id:business.id });
  };
    
    // Note: Order items are NOT saved here
   
    

    return savedOrder;
  } catch (error) {
    console.error("❌ createOrderWithoutItemsDeliveryAndReminder Transaction failed:", error);
    Sentry.captureException(error);
    throw error;
  }
}

  static async saveOrderItems(order: Order, items: OrderItemInput[], queryRunner: QueryRunner): Promise<void> {
    try {
      // Création des order items
      const orderItems = items.map((item) =>
        queryRunner.manager.create(OrderItem, {
          id_item: item.id_item,
          id_menu: item.id_menu,
          order_id: order.id,
          quantity: item.quantity,
          product_type: item.product_type,
        })
      );
      
      await queryRunner.manager.save(orderItems);
      await handleMenuItemConsumption(order, queryRunner);
    } catch (error) {
      console.error("❌ saveOrderItems failed:", error);
      Sentry.captureException(error);
      throw error;
    }
  }



  static async createOrderWithItems(data: CreateOrderWithItemssDTO): Promise<Order> {

    const queryRunner = AppDataSource.createQueryRunner()
    const orderItemsMap = new Map<number, any[]>();
    let deliveryId = null;

    await queryRunner.connect()
    await queryRunner.startTransaction()

    try {
      const business = await queryRunner.manager.findOne(Business, {
        where: { id: data.order.id_business },
      })
      if(!business) {
        throw new Error("Business not found for the provided order")
      }
    //    const businessNotAbleToCommand = !business.is_open && [OrdersOrigin.DEJAJAPP, OrdersOrigin.LIVIIAPP].includes(data.order.origin as OrdersOrigin);
    //   if (businessNotAbleToCommand) {
    //   throw new BusinessStateError(`Sorry Business Is Closed Now`,business)
    // }
      const createdOrder = await this.createOrderWithoutItemsDeliveryAndReminder(data,queryRunner);
       
        // Store items for later
        orderItemsMap.set(createdOrder.id, data.items);
        // Handle delivery if present
      if (createdOrder.type==OrderType.DELIVERY && data.deliveryData) {
        const deliveryResult= await this.handleOrderDelivery(
          createdOrder,
          data.deliveryData,
          queryRunner
        );

        if(deliveryResult.delivery_id)deliveryId=deliveryResult.delivery_id;
      }
      else if(createdOrder.type==OrderType.DELIVERY && !data.deliveryData){
        throw new Error(`Order Delivery Data Not Found`)
      }

      const items = orderItemsMap.get(createdOrder.id);
        if (items) {
          await OrderService.saveOrderItems(createdOrder, items, queryRunner);
        }
        await queryRunner.commitTransaction();
        MultiBusinessOrderService.sendNotificationForNotStartedBusiness([createdOrder])
         if(createdOrder.scheduled_at) {
          const  testJob =await OrderReminderService.scheduleReminderRedis(createdOrder.id, createdOrder.scheduled_at, {
            orderData: {}
          });
         
        }
       return createdOrder;
    } catch (error) {
      console.error("❌ Transaction failed:", error)
      Sentry.captureException(error);
       if(deliveryId) await DeliveryIntegration.deleteDelivery(deliveryId);
      await queryRunner.rollbackTransaction();
      throw error
    } finally {
      await queryRunner.release()
    }
  }


  static async handleOrderDelivery(
    order: Order,
    deliveryData: any,
    queryRunner: any
    // ou remplace par ton logger global
  ): Promise<{updatedOrder:Order,delivery_id:number}> {
    const updatedOrders: Order[] = [];

    const businessCode =[order.business.code]
    logger.info("Mutiple business codes for adding delivery ", businessCode);

    const deliveryPayload = buildDeliveryPayload(
      order,
      deliveryData,
      businessCode
    );
    logger.info(
      "Call Delivery Request From DeliveryIntegration Service",
      deliveryPayload
    );

    const delivery = await DeliveryIntegration.requestDelivery(deliveryPayload);

    if (delivery) {
      logger.info("Delivery ID received and sync with order:", delivery.id);
  
        let orderToUpdate = applyDeliveryToOrder(order, delivery);
        logger.warn(`order ${JSON.stringify(order)}`);
        order = await queryRunner.manager.save(orderToUpdate);
      
    }
    return {updatedOrder:order,delivery_id:delivery.id};
  }


  // Update Order Functions Services
  static async updateFullOrder(
  payload: UpdateOrderPayload
): Promise<Order> {

  const queryRunner = AppDataSource.createQueryRunner()
  await queryRunner.connect()
  await queryRunner.startTransaction()
  try {
    const { orderId, order, items, paymentData ,} = payload;
    
    let oldOrder = await queryRunner.manager.findOneOrFail(Order, {
      where: { id: orderId },
      relations: ["business"],
    });
    
    let updatedOrder = oldOrder;

    // 1. Mettre à jour les infos générales de la commande
    if (order) {
      updatedOrder =await this.updateOrderDetails(orderId, order, queryRunner);
    }

    if (paymentData) {
       await this.updateOrderPayments(orderId, paymentData, queryRunner);
    }

    logger.info(`Handle Order If Delivery `);
    const deliveryHandling = await DeliveryService.handleDeliveryChange(oldOrder,updatedOrder,payload.deliveryData,queryRunner);
    if (items) {
      await this.updateOrderItems(orderId, items, queryRunner);
    }

    await queryRunner.commitTransaction();
    return updatedOrder;

  } catch (error) {
    console.error("❌ updateFullOrder failed:", error);
    Sentry.captureException(error);
    throw error;
  }
}


  static async updateOrderDetails(
  orderId: number,
  orderUpdates: Partial<Order>,
  queryRunner: QueryRunner
  ): Promise<Order> {
    try {
      const existingOrder = await queryRunner.manager.findOne(Order, {
        where: { id: orderId },
      });
      if (!existingOrder) {
        throw new Error(`Order with ID ${orderId} not found`);
      }

      // Merge updates
      Object.assign(existingOrder, orderUpdates);

      const updatedOrder = await queryRunner.manager.save(existingOrder);
      return updatedOrder;
    } catch (error) {
      logger.error("❌ updateOrderDetails failed:", error);
      Sentry.captureException(error);
      throw error;
    }
  }


static async updateOrderPayments(
  orderId: number,
  paymentData: {
    payment_id?: number; // ajouté pour identifier un paiement existant
    payment_type_id: number;
    amount: number;
    payment_status?: PaymentStatus;
    type?: PaymentTypeMode;
  }[],
  queryRunner: QueryRunner
): Promise<Order> {
  try {
    const order = await queryRunner.manager.findOneByOrFail(Order, { id: orderId });

    let remaining = order.price;

    const promises = paymentData.map(async (p) => {
      if (p.payment_id) {
        // Paiement existant → mise à jour
        await queryRunner.manager.update(OrderPayment, { id: p.payment_id }, {
          payment_type_id: p.payment_type_id,
          amount: p.amount,
          order_id: orderId,
          business_id: order.id_business,
          status: p.payment_status ?? PaymentStatus.VALIDED,
        });

        if (p.payment_status !== PaymentStatus.CANCELLED) {
          if(p.type == PaymentTypeMode.CASH)
          await OperationService.orderPaymentTransaction(queryRunner,{
          amount:p.amount,
          business_id:order.id_business,
          reason:"Order Payment",
          nature:OperationNature.CASHIN,
          order_id:order.id
        })
          remaining -= p.amount;
        }
      } else {
        // Nouveau paiement → création
        const newPayment = queryRunner.manager.create(OrderPayment, {
          payment_type_id: p.payment_type_id,
          amount: p.amount,
          order_id: orderId,
          business_id: order.id_business,
          status: p.payment_status ?? PaymentStatus.VALIDED,
        });

       
        await queryRunner.manager.save(newPayment);
        if(p.type == PaymentTypeMode.CASH){
             await OperationService.orderPaymentTransaction(queryRunner,{
          amount:newPayment.amount,
          business_id:order.id_business,
          reason:"Order Payment",
          nature:OperationNature.CASHIN,
          order_id:order.id
        })
        }
     
        remaining -= p.amount;
      }
    });

    await Promise.all(promises);

    // Mise à jour du paiement global
    order.remaining_amount = remaining;
    order.payment_status =
      remaining > 0 ? OrderPaymentStatus.UNPAID : OrderPaymentStatus.PAID;

    return await queryRunner.manager.save(order);
  } catch (error) {
    console.error("❌ updateOrderPayments failed:", error);
    Sentry.captureException(error);
    throw error;
  }
}






static async updateOrderItems(
    orderId: number,
    items: OrderItemInput[],
    queryRunner: QueryRunner
  ): Promise<void> {
    const oldItems = await queryRunner.manager.find(OrderItem, {
      where: { order_id: orderId },
    });

    const order = await queryRunner.manager.findOneByOrFail(Order, { id: orderId });

    // Recalcul différentiel du stock
    // await this.handleMenuItemConsumptionDiff(order, oldItems, items, queryRunner);

    // Mise à jour en base : suppression + insertion
    await queryRunner.manager.delete(OrderItem, { order_id: orderId });

    const newEntities = items.map((i) =>
      queryRunner.manager.create(OrderItem, {
        id_item: i.id_item,
        id_menu: i.id_menu,
        quantity: i.quantity,
        product_type: i.product_type,
        order_id: orderId,
      })
    );

    await queryRunner.manager.save(newEntities);
  }

  static async handleMenuItemConsumptionDiff(
    order: Order,
    oldItems: OrderItem[],
    newItems: OrderItemInput[],
    queryRunner: QueryRunner
  ): Promise<void> {
    const oldBreakdown = await StockService.getItemBreakdownFromOrderItems(oldItems, queryRunner);
    const newBreakdown = await StockService.getItemBreakdownFromOrderItems(newItems, queryRunner);

    const allItemIds = new Set([
      ...Array.from(oldBreakdown.keys()),
      ...Array.from(newBreakdown.keys()),
    ]);

    for (const itemId of allItemIds) {
      const oldQty = oldBreakdown.get(itemId) ?? 0;
      const newQty = newBreakdown.get(itemId) ?? 0;
      const delta = newQty - oldQty;

      if (delta !== 0) {
        await StockService.adjustStock(itemId, -delta,order.id_business, queryRunner, order.origin);
      }
    }
  }

  static getUniqueBusinessesFromOrders(orders: Order[]): Business[] {
  const businessMap = new Map<number, Business>();
  for (const order of orders) {
    if (order.business && !businessMap.has(order.business.id)) {
      businessMap.set(order.business.id, order.business);
    }
  }
  return Array.from(businessMap.values());
}

static async confirmOrder(
  orderId: number){
  const queryRunner = AppDataSource.createQueryRunner();
  await queryRunner.connect();
  await queryRunner.startTransaction();
  try {
    const order = await queryRunner.manager.findOneByOrFail(Order, { id: orderId });
    if (order.status !== OrderStatus.PENDING ) {
      throw new Error(`Order with ID ${orderId} is not in PENDING status`);
    }


    if( order.type != OrderType.DELIVERY && order.scheduled_at){
        order.status = OrderStatus.PREPARING;
    }
    else if(order.type == OrderType.DELIVERY && order.scheduled_at){
      order.status = OrderStatus.ACCEPTED;
      if(!order.delivery_id) throw new Error(`Order Delivery ID Not Found`);
      await DeliveryIntegration.updateToFindingDelivery({delivery_id:order.delivery_id});
    }
    else if(order.type == OrderType.DELIVERY && !order.scheduled_at){
      order.status = OrderStatus.ACCEPTED;
      if(!order.delivery_id) throw new Error(`Order Delivery ID Not Found`);
      await DeliveryIntegration.updateToFindingDelivery({delivery_id:order.delivery_id});
    }
     else if(order.type != OrderType.DELIVERY && !order.scheduled_at){
      order.status = OrderStatus.ACCEPTED;
      if(!order.delivery_id) throw new Error(`Order Delivery ID Not Found`);
      await DeliveryIntegration.updateToFindingDelivery({delivery_id:order.delivery_id});
    }
    
     // Set automatic confirm to true
    const updatedOrder = await queryRunner.manager.save(order);
    logger.info(`Order ${orderId} automatic confirmed successfully`);


    await queryRunner.commitTransaction();
    return updatedOrder;

  }catch (error) {
    console.error("❌ confirmOrder failed:", error);
    Sentry.captureException(error);
    await queryRunner.rollbackTransaction();
    return false;
  }finally {
    await queryRunner.release();
  }
}

static async cancelOrder(orderId: number): Promise<Order> {
  const queryRunner = AppDataSource.createQueryRunner();
  await queryRunner.connect();
  await queryRunner.startTransaction();
  try {
    const order = await queryRunner.manager.findOneByOrFail(Order, { id: orderId });
    if (order.status === OrderStatus.CANCELLED) {
      throw new Error(`Order with ID ${orderId} is already cancelled`);
    }

    order.status = OrderStatus.CANCELLED;
    const updatedOrder = await queryRunner.manager.save(order);

    // If the order has a delivery, cancel it
    if (order.delivery_id) {
      await DeliveryIntegration.cancelDelivery({
        delivery_id: order.delivery_id,
      });
    }

    await queryRunner.commitTransaction();
    return updatedOrder;

  } catch (error) {
    console.error("❌ cancelOrder failed:", error);
    Sentry.captureException(error);
    await queryRunner.rollbackTransaction();
    throw error;
  } finally {
    await queryRunner.release();
  }
}

static async rejectOrder(data:{orderId: number,businessInfo:any}) {

  try {
    const order = await AppDataSource.manager.findOneByOrFail(Order, { id: data.orderId });
    if(!order) throw new Error(`Order with ID ${data.orderId} not found`);
    await n8nSendMessageToShereeqChanel({
      order:order,
      message: `Order ${order.id} a ete rejeter par le restaurant ${data.businessInfo.name} numero phone :${data.businessInfo.phone}`,
    });

  } catch (error) {
    console.error("❌ rejectOrder failed:", error);
    Sentry.captureException(error);
    throw error;
    
  }
}

static async dispatchOrder(orderId: number): Promise<Order> {
  const queryRunner = AppDataSource.createQueryRunner();
  await queryRunner.connect();
  await queryRunner.startTransaction();
  try {
    const orderRepository = queryRunner.manager.getRepository(Order);
    const order = await orderRepository.findOne({
      where:{
        id: orderId,
      },
      relations: ["business"],
    });
    if (!order) throw new Error(`Order with ID ${orderId} not found`);
    
    if (order.status == OrderStatus.DISPATCHED || order.status == OrderStatus.CANCELLED) {
      throw new Error(`Order with ID ${orderId} is not in PREPARING status`);
    }

    order.status = OrderStatus.DISPATCHED;
    await handleMenuItemConsumptionForDispatch(order, queryRunner);
    
    const updatedOrder = await queryRunner.manager.save(order);

    await queryRunner.commitTransaction();
    return updatedOrder;

  } catch (error) {
    console.error("❌ dispatchOrder failed:", error);
    Sentry.captureException(error);
    await queryRunner.rollbackTransaction();
    throw error;
  } finally {
    await queryRunner.release();
  }
}


}
