import { Order } from "../entities/Order.entity";
import { CreateOrderPayload, DeliveryData, OrderItemInput, PaymentInput } from "./SharedType";

export interface CreateMultiBusinessOrderDTO {
  orders: CreateOrderPayload[];
  deliveryData?: DeliveryData;
}
