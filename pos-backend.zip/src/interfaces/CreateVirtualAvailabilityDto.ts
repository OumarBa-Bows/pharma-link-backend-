import { ItemPreparationStatus } from "../enums/ItemPreparationStatus";

export interface CreateItemVirtualAvailabilityDto {
  menu_item_id: number;
  prepartion_time: number;
  business_id: number;
  quantity: number;
  status?: ItemPreparationStatus | null;

}

export interface UpdateItemVirtualAvailabilityDto {
  id: number;
  menu_item_id: number;
  prepartion_time: number;
  business_id: number;
  quantity: number;
  status?: ItemPreparationStatus | null;

}