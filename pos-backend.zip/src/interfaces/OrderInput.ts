import { ProductType } from "../enums/ProductType";
export interface OrderItemInput {
  id_item?: number
  id_menu?: number
  quantity: number
  product_type?: ProductType
}