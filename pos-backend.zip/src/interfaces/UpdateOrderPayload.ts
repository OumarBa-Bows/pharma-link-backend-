import { Order } from "../entities/Order.entity";
import { PaymentStatus } from "../enums/PaymentStatus";
import { OrderItemInput } from "./SharedType";

export interface UpdateOrderPayload {
    orderId: number; // obligatoire pour cibler la commande

    order?: Partial<Order>; // Infos générales de la commande à mettre à jour (prix, note, etc.)

    items?: OrderItemInput[]; // Nouvelle composition de la commande
    deliveryData?:any,
    paymentData?: {
    payment_type_id: number;
    amount: number;
    payment_status?: PaymentStatus;
    }[];
}