import { Order } from "../entities/Order.entity"
import { PaymentStatus } from "../enums/PaymentStatus"
import { ProductType } from "../enums/ProductType"

export interface CreateOrderWithItemssDTO {
  order: Partial<Order>,
  deliveryData?:any,
  paymentData:{
    payment_type_id: number
    payment_status?: PaymentStatus
    order_id?: number
    amount: number
    business_id: number
  }[],
  items: {
    id_item?: number
    id_menu?: number
    quantity: number
    product_type?: ProductType
  }[]
}