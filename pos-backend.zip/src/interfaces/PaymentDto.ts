import { PaymentStatus } from "../enums/PaymentStatus";
import { PaymentTypeMode } from "../enums/PaymentTypeMode";

  export interface PaymentDto{
    payment_id?: number; // ajouté pour identifier un paiement existant
    payment_type_id: number;
    amount: number;
    payment_status?: PaymentStatus;
    type?:PaymentTypeMode
  }