import { Request, Response } from "express";
import { logger, supabase } from "../app";
import * as Sentry from "@sentry/node";

interface OrderItem {
  order_item_id: number;
  quantity: number;
  product_type: string;
  product_category: "MENU" | "MENU_ITEM" | "UNKNOWN";
  menu?: {
    id: number;
    name_fr?: string;
    name_ar?: string;
    price?: number;
  };
  menu_item?: {
    id: number;
    name_fr?: string;
    name_ar?: string;
    price?: number;
  };
}

interface SyncDeliveryRequest {
  delivery_id: number;
  orders: {
    order_id: number;
    ticket_number: number | null;
    order_items: OrderItem[];
    business?: {
      business_name_fr: string;
      business_name_ar: string;
      phone: string | null;
      location: any;
      zone: any;
    };
  }[];
}

const syncDeliveryOrder = async (req: Request, res: Response) => {
  const startTime = Date.now();
  let deliveryId: number | undefined;

  try {
    const { delivery_id, orders } = req.body as SyncDeliveryRequest;
    deliveryId = delivery_id;

    if (!delivery_id || !Array.isArray(orders)) {
      return res.status(400).json({
        success: false,
        error: "Missing required fields: delivery_id or orders",
      });
    }

    logger.info(
      JSON.stringify({
        msg: "Sync request received",
        delivery_id,
        orders_count: orders.length,
      })
    );

    // Verify delivery exists
    const { data: currentDelivery, error: fetchError } = await supabase
      .from("deliveries")
      .select("id")
      .eq("id", delivery_id)
      .single();

    if (fetchError || !currentDelivery) {
      logger.error(
        JSON.stringify({
          msg: "Delivery not found",
          delivery_id,
          error: fetchError?.message,
        })
      );
      return res.status(404).json({
        success: false,
        error: "Delivery not found",
      });
    }

    // Always update order details without comparison
    logger.info(
      JSON.stringify({
        msg: "Updating order details",
        delivery_id,
        orders_count: orders.length,
      })
    );

    const { error: updateError } = await supabase
      .from("deliveries")
      .update({
        order_details: orders,
        updated_at: new Date().toISOString(),
      })
      .eq("id", delivery_id);

    if (updateError) {
      logger.error(
        JSON.stringify({
          msg: "Failed to update delivery",
          delivery_id,
          error: updateError.message,
        })
      );
      throw updateError;
    }

    const duration = Date.now() - startTime;
    logger.info(
      JSON.stringify({
        msg: "Delivery updated successfully",
        delivery_id,
        orders_count: orders.length,
        duration_ms: duration,
      })
    );

    return res.json({
      success: true,
      message: "Delivery updated",
      delivery_id,
      updated: true,
      duration_ms: duration,
    });
  } catch (error) {
    const duration = Date.now() - startTime;

    logger.error(
      JSON.stringify({
        msg: "Sync failed",
        deliveryId,
        error: error instanceof Error ? error.message : "Unknown error",
        stack: error instanceof Error ? error.stack : undefined,
        duration_ms: duration,
      })
    );

    Sentry.captureException(error, {
      tags: {
        operation: "sync_delivery_order",
        delivery_id: deliveryId?.toString(),
      },
      extra: {
        request_body: req.body,
        duration_ms: duration,
      },
    });

    return res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Internal server error",
      duration_ms: duration,
    });
  }
};

export default { syncDeliveryOrder };
