import { Request, Response } from "express";
import { CustomerService } from "../services/CustomerService";
import * as Sentry from "@sentry/node";

export class CustomerCOntroller {

     static async updateCustomer(req: Request, res: Response) {
        try {
        
            if (!req.body.phone || !req.body.lang) {
                return res.status(400).json({data: null, success: false, message: "Phone and language are required"});
            }
          const data = await CustomerService.updateCustomerLang({
            phone: req.body.phone,
            lang: req.body.lang,
          });
          return res.status(200).json({
            success: true,
            data,
            message: "customer lang update successful",
          });
        } catch (error: any) {
          console.error("customer lang update ", error);
          Sentry.captureException(error);
          return res.status(500).json({
            success: false,
            message: error.message || "An unexpected error occurred",
          });
        }
      }

}