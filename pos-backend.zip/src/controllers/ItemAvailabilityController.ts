import { Request, Response } from "express";
import * as Sentry from "@sentry/node";
import { CreateItemVirtualAvailabilityDto, UpdateItemVirtualAvailabilityDto } from "../interfaces/CreateVirtualAvailabilityDto";
import { ItemAvailabilityService } from "../services/ItemAvailabilityService";
import { logger } from "../app";
import { validationResult } from "express-validator";
import { ProductEstimatedService } from "../services/ProductEstimatedService";

export class ItemVirtualAvailabilityController {
    
  static async createVirtualAvailability(req: Request, res: Response) {

   
    try {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const data: CreateItemVirtualAvailabilityDto = req.body;
        const availability = await ItemAvailabilityService.createVirtualAvailability(data);
       
        return res.status(200).json(availability);
    } catch (error) {
        logger.error("Error creating virtual availability:", error);
        Sentry.captureException(error);
        return res.status(500).json({ error: "Internal server error" });
    }
  }

  static async completeVirtualAvailability(req: Request, res: Response) {

   
    try {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const virtual_item_id = req.body.id;
        const availability = await ItemAvailabilityService.completeVirtualAvailability(virtual_item_id);
        if (!availability) {
            return res.status(404).json({ error: "Virtual availability not found" });
        }
        return res.status(200).json(availability);
    } catch (error) {
        logger.error("Error creating virtual availability:", error);
        Sentry.captureException(error);
        return res.status(500).json({ error: "Internal server error" });
    }
  }

  static async getVirtualItemsInPreparation(req: Request, res: Response) {
    try {
       const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
      const virtualItems = await ItemAvailabilityService.getVirtualItmesInPreparation(req.body);
      return res.status(200).json({data:virtualItems});
    } catch (error) {
      logger.error("Error fetching virtual items in preparation:", error);
      Sentry.captureException(error);
      return res.status(500).json({ error: "Internal server error" });
    }
  }

   static async editVirtualAvailability(req: Request, res: Response) {

   
    try {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        const data: UpdateItemVirtualAvailabilityDto = req.body;
        const availability = await ItemAvailabilityService.editVirtualAvailability(data);
        return res.status(200).json(availability);
    } catch (error) {
       
        Sentry.captureException(error);
        return res.status(500).json({ message: "Internal server error",error:`${error}` });
    }
  }

  static async getProductEstimatedDelivery(req: Request, res: Response){

    try {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        
        const products = await ProductEstimatedService.getProductEstimatedDeliveryTime(req.body.business_id);
       
        return res.status(200).json({data:products});
    } catch (error) {
        logger.error("getProductEstimatedDeliveryTime:", error);
        Sentry.captureException(error);
        return res.status(500).json({ error: "Internal server error" });
    }
  }

}