import { logger } from "../app";
import { sendOrderNotificationByStatus } from "../utils/notifications/order-message";
import * as Sentry from "@sentry/node";

export class OrderWebhookController {

    static async handleOrderNotificationWebhook(req: any, res: any) {
        try {
             const payload = req.body || JSON.parse(req.rawBody);
            logger.info("Received order notification webhook")
           
            const newOrder = payload.new;
            const oldOrder = payload.old;
               
            if(!oldOrder && newOrder){
                logger.info("New order created", newOrder.id);
                await sendOrderNotificationByStatus({
                order:newOrder,
                message: req.body.message,
                phone: newOrder.customer_phone,
                
            
            })
            }
            else if(!newOrder){
                logger.warn("No new order found in the payload");
                return res.status(400).send({success:false, message:"No new order found"});
            }
            else if(oldOrder && newOrder){
                if(oldOrder.status === newOrder.status){
                    logger.info(`Order status has not changed, ${newOrder.id}`);
                    return res.status(200).send({success:true, message:"Order status has not changed"});
                }else{
                    logger.info(`Order status has changed, ${newOrder.id}, "from", ${oldOrder.status}, "to", ${newOrder.status}`);
                     await sendOrderNotificationByStatus({
                order:newOrder,
                message: req.body.message,
                phone: newOrder.customer_phone,
            
            })
                }
            }

           

            return res.status(200).send({success:true});
        } catch (error) {
            console.error("Error handling order notification webhook:", error);
            Sentry.captureException(error);
            return res.status(500).send({success:false});
        }
        


    }
}