import { validationResult } from "express-validator";
import { Request, Response } from "express"
import { AppDataSource, logger } from "../app";
import { PaymentService } from "../services/PaymentService";
import * as Sentry from "@sentry/node";

export class PaymentController {

    static async createOrderPayment(req:Request, res:Response){

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
        }

        const queryRunner = AppDataSource.createQueryRunner()
        
        await queryRunner.connect()
        await queryRunner.startTransaction()
        try {
        
        const payment = await PaymentService.addPayment(queryRunner,req.body);
        await queryRunner.commitTransaction()
        return res.status(200).json({message:"Operation Successful",data:payment})
        } catch (error) {
        Sentry.captureException(error)
        await queryRunner.rollbackTransaction();
        return res.status(500).json({message:"Internal Server Error",error:`${error}`})
        }finally{
        await queryRunner.release()
        }
    }

    static async cancelOrderPayment(req:Request, res:Response){

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
        }

        const queryRunner = AppDataSource.createQueryRunner()
        
        await queryRunner.connect()
        await queryRunner.startTransaction()
        try {
        
        const payment = await PaymentService.cancelPayment(queryRunner,req.body);
        await queryRunner.commitTransaction()
        return res.status(200).json({message:"order payment cancelled succesfuly",data:payment})
        } catch (error) {
        Sentry.captureException(error)
        await queryRunner.rollbackTransaction();
        return res.status(500).json({message:"Internal Server Error",error:`${error}`})
        }finally{
        await queryRunner.release()
        }
    }

}