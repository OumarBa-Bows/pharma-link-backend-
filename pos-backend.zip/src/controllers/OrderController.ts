// src/modules/orders/controllers/OrderController.ts

import { Request, Response } from "express"
import { OrderService } from "../services/OrderService"
import { AppDataSource, logger } from "../app"
import { validationResult } from "express-validator";
import { OrderReminderService } from "../services/OrderReminderService";
import { MultiBusinessOrderService } from "../services/MultiBusinessOrderService";
import { StockError } from "../Errors/StockError";
import { BusinessStateError } from "../Errors/BusinnessStateError";
import { redis } from "../configs/redis.config";
import { GlobalSettingValue } from "../configs/GlobalSettingValue";
import { GlobalKeys } from "../configs/GlobalKeys.config";
import { OrdersOrigin } from "../enums/OrderOrigin";
import { OrderType } from "../enums/OrderType";
import * as Sentry from "@sentry/node";
import { PaymentService } from "../services/PaymentService";
import { OperationService } from "../services/OperationService";
import { OperationNature } from "../enums/OperationNature";

export class OrderController {
  static async createOrder(req: Request, res: Response) {
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    try {
      const input = req.body

      const order = await OrderService.createOrderWithItems(input)
      if (!order) {
        return res.status(400).json({
          success: false,
          message: "Order creation failed",
        })
      }
        logger.info("✅ Order created successfully:", order.id)
        // redis.set(`pendingOrder_${order.id}`, order.id, "EX", 60)
        if(order.type== OrderType.DELIVERY){
          await redis.set(`${GlobalKeys.PENDING_ORDER_KEY}${order.id}`, order.id, "EX", GlobalSettingValue.PENDING_ORDER_TTL);
        }
       
        
        return res.status(200).json({
            success: true,
            message: "Order created successfully",
            data: order,
        })
    } catch (error: any) {
      Sentry.captureException(error);
      logger.error("❌ Order creation failed:", error)

      if (error instanceof StockError) {
        return res.status(409).json({
          success: false,
          error: "STOCK_ERROR",
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      else if(error instanceof BusinessStateError){
      return res.status(409).json({
          success: false,
          error: error.code,
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      return res.status(500).json({
        success: false,
        message: error.message || "Internal Server Error",
      })
    }
  }



  static async createMultiBusinessOrder(req: Request, res: Response) {
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    try {
      const input = req.body

      const orders = await MultiBusinessOrderService.createMultipleOrders(input)
      if (!orders) {
        return res.status(400).json({
          success: false,
          message: "Order creation failed",
        })
      }
        logger.info("✅ Order created successfully:")
        return res.status(200).json({
            success: true,
            message: "Order created successfully",
            data: orders,
        })
    } catch (error: any) {
      Sentry.captureException(error);
      logger.error("❌ Order creation failed:", error)
         if (error instanceof StockError) {
          return res.status(409).json({
              success: false,
            error: "STOCK_ERROR",
            code:error.code,
            business:error.business,
            message:error.message
          });
      }
      else if(error instanceof BusinessStateError){
      return res.status(409).json({
          success: false,
          error: error.code,
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      return res.status(500).json({
        success: false,
        message: error.message || "Internal Server Error",
      })
    }
  }

  static async updateOrder(req: Request, res: Response) {
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    try {
      const input = req.body

      const order = await OrderService.updateFullOrder(input)
      if (!order) {
        return res.status(400).json({
          success: false,
          message: "Order creation failed",
        })
      }
        logger.info("✅ Order created successfully:", order.id)
        return res.status(200).json({
            success: true,
            message: "Order created successfully",
            data: order,
        })
    } catch (error: any) {
      Sentry.captureException(error);
      logger.error("❌ Order creation failed:", error)

      if (error instanceof StockError) {
        return res.status(409).json({
          success: false,
          error: "STOCK_ERROR",
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      else if(error instanceof BusinessStateError){
      return res.status(409).json({
          success: false,
          error: error.code,
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      return res.status(500).json({
        success: false,
        message: error.message || "Internal Server Error",
      })
    }
  }

  static async confirmOrder(req: Request, res: Response) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    try {
      const orderId = Number(req.body.orderId)
      const order = await OrderService.confirmOrder(orderId)
      if (!order) {
        return res.status(400).json({
          success: false,
          message: "Order confirmation failed",
        })
      }
        logger.info("✅ Order confirmed successfully:", order.id)
        return res.status(200).json({
            success: true,
            message: "Order confirmed successfully",
            data: order,
        })
    } catch (error: any) {
      Sentry.captureException(error);
      logger.error("❌ Order confirmation failed:", error)

      if (error instanceof StockError) {
        return res.status(409).json({
          success: false,
          error: "STOCK_ERROR",
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      else if(error instanceof BusinessStateError){
      return res.status(409).json({
          success: false,
          error: error.code,
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      return res.status(500).json({
        success: false,
        message: error.message || "Internal Server Error",
      })
    }
  }

  static async rejectOrder(req: Request, res: Response) {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    try {
      const orderId = Number(req.body.orderId)
      const order = await OrderService.rejectOrder({
        orderId: orderId,
        businessInfo: req.body.businessInfo
      })
     
       
        return res.status(200).json({
            success: true,
            message: "Order rejected successfully",
            data: order,
        })
    } catch (error: any) {
      Sentry.captureException(error);
      logger.error("❌ Order rejection failed:", error)

      if (error instanceof StockError) {
        return res.status(409).json({
          success: false,
          error: "STOCK_ERROR",
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      else if(error instanceof BusinessStateError){
      return res.status(409).json({
          success: false,
          error: error.code,
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      return res.status(500).json({
        success: false,
        message: error.message || "Internal Server Error",
      })
    }
  }

  static async dispatchOrder(req: Request, res: Response) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    try {
      const orderId = Number(req.body.orderId)
      const order = await OrderService.dispatchOrder(orderId)
      if (!order) {
        return res.status(400).json({
          success: false,
          message: "Order dispatch failed",
        })
      }
        logger.info("✅ Order dispatched successfully:", order.id)
        return res.status(200).json({
            success: true,
            message: "Order dispatched successfully",
            data: order,
        })
    } catch (error: any) {
      Sentry.captureException(error);
      logger.error("❌ Order dispatch failed:", error)

      if (error instanceof StockError) {
        return res.status(409).json({
          success: false,
          error: "STOCK_ERROR",
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      else if(error instanceof BusinessStateError){
      return res.status(409).json({
          success: false,
          error: error.code,
          code:error.code,
          business:error.business,
          message:error.message
        });
      }
      return res.status(500).json({
        success: false,
        message: error.message || "Internal Server Error",
      })
    }
  }





}
