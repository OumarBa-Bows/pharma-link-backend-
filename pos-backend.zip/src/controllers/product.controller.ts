import { Request, Response } from "express";
import { logger, meilisearchClient, supabaseLiviiPos } from "../app";
import * as Sentry from "@sentry/node";
import { Index } from "meilisearch";

export interface Product {
  id: number;
  code: string;
  unique_key: string;
  source_table: string;
  name_fr: string;
  name_ar: string;
  description_fr: string;
  description_ar: string;
  price: number;
  image_url: string | null;
  is_available: boolean;
  availability: boolean;
  is_sellable: boolean;
  is_inventory_tracked: boolean;
  type: string | null;
  quantity: number;
  daily_quantity: number;
  category_id: number | null;
  category_name_fr: string;
  category_name_ar: string;
  display_order: number;
  business_id: number;
  business_code: string;
  business_name_fr: string;
  business_name_ar: string;
  business_logo: string;
  business_status: string;
  business_type: string;
  business_owner_id: number;
  business_created_at: string | null;
  business_updated_at: string | null;
  business_started_at: string | null;
  business_is_started: boolean;
  business_location: string | null;
  business_phone: string | null;
  business_popularity: number;
  business_zone: string | null;
  business_is_open: boolean;
  business_whatsapp_number: string | null;
  business_schedule: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export const searchProducts = async (req: Request, res: Response) => {
  const { businessId, search, languageCode, categoryId, filters } = req.body;
  const indexName = process.env.MEILISEARCH_INDEX_PRODUCTS || "products";

  if (!languageCode) {
    logger.error("Missing languageCode");
    Sentry.captureException({
      error: "languageCode is required",
    });
    return res.status(400).json({ error: "languageCode is required" });
  }

  logger.info(
    `Products search request: businessId=${businessId}, search="${search}", categoryId=${categoryId}, languageCode=${languageCode}`
  );

  try {
    if (businessId) {
      logger.info(`Fetching products for business: ${businessId}`);

      let filterArray = [`business_id = ${businessId}`, "is_available = true"];

      // Always filter out non-sellable items unless explicitly requested
      if (filters?.is_sellable !== undefined) {
        filterArray.push(`is_sellable = ${filters.is_sellable}`);
      } else {
        filterArray.push(`is_sellable = true`);
      }

      if (categoryId) {
        filterArray.push(`category_id = ${categoryId}`);
        logger.info(`Filtering by category: ${categoryId}`);
      }

      if (
        filters?.min_price !== undefined ||
        filters?.max_price !== undefined
      ) {
        const minPrice = filters.min_price || 0;
        const maxPrice = filters.max_price || 999999;
        filterArray.push(`price >= ${minPrice} AND price <= ${maxPrice}`);
      }

      if (filters?.type) {
        filterArray.push(`type = "${filters.type}"`);
      }

      if (filters?.source_table) {
        filterArray.push(`source_table = "${filters.source_table}"`);
      }

      if (search && search.trim() !== "") {
        logger.info(
          `Searching for products matching "${search}" within business: ${businessId}`
        );

        let attributesToSearchOn = [
          "name_fr",
          "name_ar",
          "description_fr",
          "description_ar",
          "code",
        ];

        if (languageCode === "fr") {
          attributesToSearchOn = [
            "name_fr",
            "description_fr",
            "category_name_fr",
            "code",
          ];
        } else if (languageCode === "ar") {
          attributesToSearchOn = [
            "name_ar",
            "description_ar",
            "category_name_ar",
            "code",
          ];
        }

        const response = await meilisearchClient
          .index(indexName)
          .search(search, {
            filter: filterArray,
            limit: 50,
            attributesToSearchOn: attributesToSearchOn,
            sort: ["display_order:asc", "name_fr:asc"],
          });

        const products = response.hits;

        logger.info(
          `Found ${products.length} products matching "${search}" in business ${businessId}`
        );

        return res.status(200).json({
          products: products,
          total: response.estimatedTotalHits || response.hits.length,
        });
      }

      if (categoryId && !search) {
        const response = await meilisearchClient.index(indexName).search("", {
          filter: filterArray,
          limit: 100,
          sort: ["display_order:asc", "name_fr:asc"],
        });

        return res.status(200).json({
          products: response.hits,
          total: response.estimatedTotalHits || response.hits.length,
        });
      }

      const categoriesResponse = await meilisearchClient
        .index(indexName)
        .search("", {
          filter: [
            `business_id = ${businessId}`,
            "is_available = true",
            "is_sellable = true",
          ],
          facets: ["category_id"],
          limit: 0,
        });

      const productsResponse = await meilisearchClient
        .index(indexName)
        .search("", {
          filter: filterArray,
          limit: 1000,
          sort: ["display_order:asc", "category_id:asc", "name_fr:asc"],
        });

      const products = productsResponse.hits;

      const categoryDistribution =
        categoriesResponse.facetDistribution?.category_id || {};

      const categories = Object.keys(categoryDistribution)
        .map((categoryId) => {
          const categoryProducts = products.filter(
            (item) => item.category_id?.toString() === categoryId
          );
          const firstProduct = categoryProducts[0] || {};

          return {
            category_id: categoryId,
            category_name_fr: firstProduct.category_name_fr || "",
            category_name_ar: firstProduct.category_name_ar || "",
            display_order: firstProduct.display_order || 0,
            product_count: categoryDistribution[categoryId],
            products: categoryProducts,
          };
        })
        .sort((a, b) => b.display_order - a.display_order);

      return res.status(200).json({
        categories: categories,
        allProducts: products.sort((a, b) => {
          // First, sort by source_table: menu items first, then menu_item
          if (a.source_table === "menu" && b.source_table === "menu_item")
            return -1;
          if (a.source_table === "menu_item" && b.source_table === "menu")
            return 1;

          // If both are menu_item, prioritize is_inventory_tracked items first
          if (
            a.source_table === "menu_item" &&
            b.source_table === "menu_item"
          ) {
            if (a.is_inventory_tracked && !b.is_inventory_tracked) return -1;
            if (!a.is_inventory_tracked && b.is_inventory_tracked) return 1;
          }

          // If same source_table, sort by display_order, then category_id, then name_fr
          if (a.source_table === b.source_table) {
            if (a.display_order !== b.display_order)
              return a.display_order - b.display_order;
            if ((a.category_id || 0) !== (b.category_id || 0))
              return (a.category_id || 0) - (b.category_id || 0);
            return a.name_fr.localeCompare(b.name_fr);
          }

          return 0;
        }),
        total: products.length,
      });
    } else if (search) {
      logger.info(`Searching products with query: ${search}`);

      let attributesToSearchOn = [
        "name_fr",
        "name_ar",
        "description_fr",
        "description_ar",
        "code",
      ];

      if (languageCode === "fr") {
        attributesToSearchOn = [
          "name_fr",
          "description_fr",
          "business_name_fr",
          "category_name_fr",
          "code",
        ];
      } else if (languageCode === "ar") {
        attributesToSearchOn = [
          "name_ar",
          "description_ar",
          "business_name_ar",
          "category_name_ar",
          "code",
        ];
      }

      const response = await meilisearchClient.index(indexName).search(search, {
        filter: ["is_available = true", "is_sellable = true"],
        limit: 500,
        attributesToSearchOn: attributesToSearchOn,
        sort: ["display_order:asc"],
        facets: ["business_id"],
      });

      const products = response.hits;

      logger.info(
        `Found ${products.length} products matching search: ${search}`
      );

      return res.status(200).json({
        products: products,
        total: response.estimatedTotalHits || response.hits.length,
        businessFacets: response.facetDistribution?.business_id || {},
      });
    } else if (req.body.code) {
      logger.info(`Searching product by code: ${req.body.code}`);

      const filterArray = [`code = "${req.body.code}"`];

      if (businessId) {
        filterArray.push(`business_id = ${businessId}`);
      }

      const response = await meilisearchClient.index(indexName).search("", {
        filter: filterArray,
        limit: 1,
      });

      if (response.hits.length === 0) {
        return res.status(404).json({
          error: "Product not found",
        });
      }

      const product = response.hits[0];

      return res.status(200).json({
        product,
      });
    }
    // Case 4: No specific parameters - return 400 error
    else {
      logger.warn("Request missing required parameters");
      return res.status(400).json({
        error: "Either businessId, search, or code parameter is required",
      });
    }
  } catch (error) {
    logger.error(`Error in searchProducts: ${error}`);
    Sentry.captureException({
      error: `Unexpected error occurred in products search: ${error}`,
    });
    return res.status(500).json({ error: "Internal server error" });
  }
};
export const syncProductsToMeilisearch = async (
  req: Request,
  res: Response
) => {
  try {
    logger.info("Starting full products sync to MeiliSearch");

    const indexName = process.env.MEILISEARCH_INDEX_PRODUCTS || "products";
    const productsIndex: Index = meilisearchClient.index(indexName);

    // Step 1: Delete existing documents
    logger.info(
      "Deleting existing documents from MeiliSearch products index..."
    );
    const deleteTask = await productsIndex.deleteAllDocuments();
    logger.info(`Deletion task submitted: taskUid = ${deleteTask.taskUid}`);

    // Wait for deletion to complete
    await productsIndex.waitForTask(deleteTask.taskUid);
    logger.info("All documents deleted from MeiliSearch products index.");

    // Step 2: Fetch all products from Supabase view
    logger.info("Fetching products from business_products_view...");

    // Fetch in batches to handle large datasets
    const batchSize = 1000;
    let offset = 0;
    let allProducts: any[] = [];
    let hasMore = true;

    while (hasMore) {
      const {
        data: products,
        error,
        count,
      } = await supabaseLiviiPos
        .from("business_products_view")
        .select("*", { count: "exact" })
        .range(offset, offset + batchSize - 1)
        .order("business_id", { ascending: true })
        .order("display_order", { ascending: true })
        .order("category_id", { ascending: true });

      if (error) {
        logger.error("Failed to fetch products from Supabase", error);
        return res.status(500).json({
          error: "Failed to fetch products",
          details: error,
        });
      }

      if (products && products.length > 0) {
        allProducts = allProducts.concat(products);
        offset += batchSize;

        // Check if we've fetched all products
        hasMore = products.length === batchSize;

        logger.info(`Fetched ${allProducts.length} products so far...`);
      } else {
        hasMore = false;
      }
    }

    if (allProducts.length === 0) {
      logger.info("No products to sync");
      return res.status(200).json({ message: "No products to sync" });
    }

    logger.info(`Total products fetched: ${allProducts.length}`);

    // Step 3: Use products directly from view

    // Step 4: Upload to MeiliSearch in batches
    logger.info("Uploading products to MeiliSearch...");

    // MeiliSearch recommends batches of 1000 documents
    const uploadBatchSize = 1000;
    const uploadTasks = [];

    for (let i = 0; i < allProducts.length; i += uploadBatchSize) {
      const batch = allProducts.slice(i, i + uploadBatchSize);
      const response = await productsIndex.addDocuments(batch, {
        primaryKey: "code",
      });

      uploadTasks.push(response.taskUid);
      logger.info(
        `Uploaded batch ${Math.floor(i / uploadBatchSize) + 1}, taskUid: ${
          response.taskUid
        }`
      );
    }

    // Wait for all upload tasks to complete
    logger.info("Waiting for all upload tasks to complete...");
    for (const taskUid of uploadTasks) {
      await productsIndex.waitForTask(taskUid);
    }

    logger.info("Products synced successfully to MeiliSearch");

    // Step 5: Get index stats
    const stats = await productsIndex.getStats();

    return res.status(200).json({
      message: "Products synced successfully",
      stats: {
        totalProducts: allProducts.length,
        numberOfDocuments: stats.numberOfDocuments,
        isIndexing: stats.isIndexing,
      },
      uploadTasks: uploadTasks,
    });
  } catch (err) {
    logger.error("Failed to sync products to MeiliSearch", err);
    Sentry.captureException(err);
    return res.status(500).json({
      error: "Sync failed",
      details: err instanceof Error ? err.message : err,
    });
  }
};

export const syncProductFromTrigger = async (req: Request, res: Response) => {
  const { id, table_name } = req.body;

  if (!id || !table_name) {
    logger.error("Missing id or table_name in webhook payload");
    return res.status(400).json({ error: "Missing id or table_name" });
  }

  logger.info(`Received sync request for ${table_name} ID: ${id}`);

  try {
    const indexName = process.env.MEILISEARCH_INDEX_PRODUCTS || "products";
    const productsIndex: Index = meilisearchClient.index(indexName);

    // Fetch from business_products_view which combines menu and menu_item
    logger.info(
      `Fetching product from business_products_view (source_table: ${table_name}, ID: ${id})`
    );

    const { data: product, error } = await supabaseLiviiPos
      .from("business_products_view")
      .select("*")
      .eq("id", id)
      .eq("source_table", table_name)
      .single();

    if (error || !product) {
      logger.error(
        `Failed to fetch ${table_name} (ID: ${id}): ${JSON.stringify(error)}`
      );
      return res.status(404).json({ error: `${table_name} not found` });
    }

    logger.info(`Product fetched: ${JSON.stringify(product.code)}`);

    logger.info(`Upserting product into MeiliSearch index '${indexName}'...`);
    const addResponse = await productsIndex.addDocuments([product], {
      primaryKey: "code",
    });

    logger.info(
      `MeiliSearch addDocuments response: ${JSON.stringify(addResponse)}`
    );

    logger.info(
      `Waiting for MeiliSearch task UID ${addResponse.taskUid} to complete...`
    );
    const taskResult = await productsIndex.waitForTask(addResponse.taskUid);

    logger.info(`MeiliSearch task completed: ${JSON.stringify(taskResult)}`);

    return res.status(200).json({ success: true, task: taskResult });
  } catch (err) {
    logger.error(`Error syncing ${table_name} ${id} to MeiliSearch: ${err}`);
    Sentry.captureException(err);
    return res
      .status(500)
      .json({ error: "Internal error", details: String(err) });
  }
};
export const deleteProductFromTrigger = async (req: Request, res: Response) => {
  const { code } = req.body;

  if (!code) {
    logger.error("Missing code in delete webhook payload");
    return res.status(400).json({ error: "Missing code" });
  }

  logger.info(`Received delete request for product code: ${code}`);

  try {
    const indexName = process.env.MEILISEARCH_INDEX_PRODUCTS || "products";
    const productsIndex: Index = meilisearchClient.index(indexName);

    logger.info(`Deleting product from MeiliSearch index '${indexName}'...`);
    const deleteResponse = await productsIndex.deleteDocument(code);

    logger.info(
      `MeiliSearch deleteDocument response: ${JSON.stringify(deleteResponse)}`
    );

    logger.info(
      `Waiting for MeiliSearch task UID ${deleteResponse.taskUid} to complete...`
    );
    const taskResult = await productsIndex.waitForTask(deleteResponse.taskUid);

    logger.info(
      `MeiliSearch delete task completed: ${JSON.stringify(taskResult)}`
    );

    return res.status(200).json({ success: true, task: taskResult });
  } catch (err) {
    logger.error(`Error deleting product ${code} from MeiliSearch: ${err}`);
    Sentry.captureException(err);
    return res
      .status(500)
      .json({ error: "Internal error", details: String(err) });
  }
};

export const syncBusinessProductsToMeilisearch = async (
  req: Request,
  res: Response
) => {
  const { business_id } = req.body;

  if (!business_id) {
    logger.error("Missing business_id in webhook payload");
    return res.status(400).json({ error: "Missing business_id" });
  }

  logger.info(`Received sync request for business ID: ${business_id}`);

  try {
    const indexName = process.env.MEILISEARCH_INDEX_PRODUCTS || "products";
    const productsIndex: Index = meilisearchClient.index(indexName);

    // Fetch all products for this business from the view
    logger.info(
      `Fetching all products for business ${business_id} from business_products_view`
    );

    const { data: products, error } = await supabaseLiviiPos
      .from("business_products_view")
      .select("*")
      .eq("business_id", business_id)
      .order("display_order", { ascending: true })
      .order("category_id", { ascending: true });

    if (error) {
      logger.error(
        `Failed to fetch products for business ${business_id}: ${JSON.stringify(
          error
        )}`
      );
      return res.status(500).json({
        error: "Failed to fetch products",
        details: error,
      });
    }

    if (!products || products.length === 0) {
      logger.info(`No products found for business ${business_id}`);
      return res.status(200).json({
        message: "No products to sync",
        businessId: business_id,
        productCount: 0,
      });
    }

    logger.info(
      `Found ${products.length} products for business ${business_id}`
    );

    // Update all products in Meilisearch
    logger.info(`Updating ${products.length} products in MeiliSearch...`);

    const updateResponse = await productsIndex.addDocuments(products, {
      primaryKey: "code",
    });

    logger.info(
      `MeiliSearch update response: ${JSON.stringify(updateResponse)}`
    );

    // Wait for the task to complete
    logger.info(
      `Waiting for MeiliSearch task ${updateResponse.taskUid} to complete...`
    );
    const taskResult = await productsIndex.waitForTask(updateResponse.taskUid);

    logger.info(`MeiliSearch task completed: ${JSON.stringify(taskResult)}`);

    return res.status(200).json({
      success: true,
      message: `Successfully synced ${products.length} products for business ${business_id}`,
      businessId: business_id,
      productCount: products.length,
      task: taskResult,
    });
  } catch (err) {
    logger.error(
      `Error syncing products for business ${business_id} to MeiliSearch: ${err}`
    );
    Sentry.captureException(err);
    return res
      .status(500)
      .json({ error: "Internal error", details: String(err) });
  }
};
