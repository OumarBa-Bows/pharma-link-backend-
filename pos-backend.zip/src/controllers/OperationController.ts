// src/modules/orders/controllers/OrderController.ts

import { Request, Response } from "express"

import { AppDataSource, logger } from "../app"
import { validationResult } from "express-validator";

import * as Sentry from "@sentry/node";

import { OperationService } from "../services/OperationService";
import { OperationNature } from "../enums/OperationNature";

export class OperationController {

  static async cashInOperation(req:Request, res:Response){
     const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const queryRunner = AppDataSource.createQueryRunner()
    
    await queryRunner.connect()
    await queryRunner.startTransaction()
    try {
      logger.info("CashIn Operation Request",req.body)
      req.body.nature=OperationNature.CASHIN;
      const operation = await OperationService.orderPaymentTransaction(queryRunner,req.body);
      await queryRunner.commitTransaction()
      return res.status(200).json({message:"Operation Successful",data:operation})
    } catch (error) {
      Sentry.captureException(error)
      await queryRunner.rollbackTransaction();
      return res.status(500).json({message:"Internal Server Error"})
    }finally{
      await queryRunner.release()
    }
  }

  static async cashOutOperation(req:Request, res:Response){
     const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const queryRunner = AppDataSource.createQueryRunner()
    
    await queryRunner.connect()
    await queryRunner.startTransaction()
    try {
      logger.info("Initiating CashOut Operation")
      req.body.nature=OperationNature.CASHOUT;
      const operation = await OperationService.orderPaymentTransaction(queryRunner,req.body);
      await queryRunner.commitTransaction()
     return res.status(200).json({message:"Operation Successful",data:operation})
    } catch (error) {
      Sentry.captureException(error)
      await queryRunner.rollbackTransaction();
      return res.status(500).json({message:"Internal Server Error"})
    }finally{
      await queryRunner.release()
    }
  }
}
