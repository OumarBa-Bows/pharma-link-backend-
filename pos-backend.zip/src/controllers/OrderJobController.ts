import { Request, Response } from "express";
import { OrderReminderService } from "../services/OrderReminderService";
import * as Sentry from "@sentry/node";

export class OrderJobController {
  static async createReminder(req: Request, res: Response) {
    try {
      const { orderId } = req.body;
      const data = await OrderReminderService.createOrderReminder(orderId);
      return res.status(200).json({
        success: true,
        data,
        message: "order reminder successful",
      });
    } catch (error: any) {
      console.error("Order reminder error:", error);
      Sentry.captureException(error);
      return res.status(500).json({
        success: false,
        message: error.message || "An unexpected error occurred",
      });
    }
  }
}