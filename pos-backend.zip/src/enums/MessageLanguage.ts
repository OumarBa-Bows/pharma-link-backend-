export enum MessageLanguage {
    FR = "FR",
    AR = "AR",
    EN = "EN"
  }