export enum BusinessType {

  PREMIUM = "PREMIUM",
  PRO = "PRO"
 
}