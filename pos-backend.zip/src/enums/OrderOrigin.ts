export enum OrdersOrigin {
  LIIVIPOS = "LIIVIPOS",
  DEJAJAPP = "DEJAJAPP",
  ADMIN = "ADMIN",
  LIVIIAPP = "LIVIIAPP",
  JAAVAR="JAAVAR"
}
