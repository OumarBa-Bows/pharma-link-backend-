export enum OrderPaymentStatus {
  UNPAID = "UNPAID",
  PAID = "PAID",
  PARTIAL_PAID = "PARTIAL_PAID",
  // ...
}
