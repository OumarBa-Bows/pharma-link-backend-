export enum PaymentStatus {
  VALIDED = "VALIDED",
  CANCELLED = "CANCELLED"
}