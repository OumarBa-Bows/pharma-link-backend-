export enum OrderJobStatus {
  STARTED = 'STARTED',
  CLOSED = 'CLOSED'
}