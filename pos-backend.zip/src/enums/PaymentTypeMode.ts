export enum PaymentTypeMode {
  CASH = "CASH",
  WALLET = "WALLET"
}