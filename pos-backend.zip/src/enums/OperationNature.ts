export enum OperationNature {

  CASHIN = "CASHIN",
  CASHOUT = "CASHOUT",
  DEFAULT ="DEFAULT"
 
}