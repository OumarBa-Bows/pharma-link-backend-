export enum ItemPreparationStatus {

  IN_PREPARATION = "IN_PREPARATION",
  READY = "READY"
 
}