export enum ProductType {
  MENU = "menu",
  ITEM = "menu_item",
  // autres types si définis...
}